"""Switch the shared RTL replay to one-app/solo cases and add a read-only head probe."""

from pathlib import Path


def edit(path, changes):
    path = Path(path)
    source = path.read_text()
    for old, new in changes:
        assert source.count(old) == 1, old
        source = source.replace(old, new)
    path.write_text(source)


edit("run_matrix.py", (
    ('            stats[f"{label}_all"] = max(done for d, rel, done in all_items)',
     '''            if not all_items:
                continue
            stats[f"{label}_all"] = max(done for d, rel, done in all_items)'''),
    ('''    assert max(messages[2, i + scenario.count][2] for i in range(scenario.count)) == events["CC_STEP"][0][0]''',
     '''    if scenario.count:
        assert max(messages[2, i + scenario.count][2] for i in range(scenario.count)) == events["CC_STEP"][0][0]
    else:
        assert not events["CC_STEP"]'''),
    ('''        elif tag in ("CFG_TRIGGER", "SNAP", "COMMIT"):''',
     '''        elif tag == "CC_HEAD":
            events[tag].append(tuple(map(int, fields[1:])))
        elif tag in ("CFG_TRIGGER", "SNAP", "COMMIT"):'''),
))

probe = """
 // Observe each CC flit that is already at the head of a router input.
 // The sampled grant and readiness are the same combinational signals used
 // by the router on this edge. This probe does not influence arbitration.
 for(genvar r=0;r<16;r++) begin: cc_probe
  always @(posedge clk) if(!reset && cc_count>0) begin
   for(int ip=0;ip<5;ip++) begin
    int d, q, op, v, selected_q, ready, grant_here, other_app;
    q=mesh.routers[r].r.queued[ip][63:32];
    if(mesh.routers[r].r.full[ip] && q>=0 && q<nframes && app[q]==2) begin
     d=int'(mesh.routers[r].r.queued[ip][68:65]);
     op=d%4>r%4 ? 0 : d%4<r%4 ? 1 : d/4>r/4 ? 2 : d/4<r/4 ? 3 : 4;
     if(op<4) begin
      v=op==0 ? r+1 : op==1 ? r-1 : op==2 ? r+4 : r-4;
      ready=mesh.rd[r][op];
      grant_here=mesh.routers[r].r.grant[op][ip];
      selected_q=mesh.out_flit[r][op*69+32+:32];
      other_app=ready && mesh.ov[r][op] && !grant_here ? app[selected_q] : -1;
      $display("CC_HEAD,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d",
               id[q],mesh.routers[r].r.queued[ip][31:0],r,v,c,ready,grant_here,other_app);
     end
    end
   end
  end
 end
"""
edit("experiment_tb.sv", (("endmodule", probe + "endmodule"),))

