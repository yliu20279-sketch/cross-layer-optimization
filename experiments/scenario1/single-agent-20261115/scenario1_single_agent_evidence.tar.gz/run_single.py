"""Run matched single-MoE mixed, solo, and staggered tests on the existing RTL."""

from collections import Counter, defaultdict
from concurrent.futures import ThreadPoolExecutor
from dataclasses import replace
import json
from pathlib import Path
import statistics

import planner
from run_matrix import ROOT, Scenario, replay, stimulus, write_csv


BASE = "B_mesh"
DESIGN = "B_full"
WINDOWS = (
    ("fixed_r2_one", "R0002", 9, 1, 17803),
    ("fixed_r2_eight", "R0002", 9, 8, 17803),
    ("fixed_r7_early", "R0007", 8, 8, 17175),
    ("fixed_r7_eight", "R0007", 8, 8, 17803),
    ("fixed_r10_eight", "R0010", 9, 8, 17803),
    ("fixed_r14_eight", "R0014", 8, 8, 17803),
    ("target_r2_one", "R0002", 9, 1, None),
    ("target_r2_eight", "R0002", 9, 8, None),
    ("target_r7_eight", "R0007", 8, 8, None),
    ("target_r14_eight", "R0014", 8, 8, None),
)


def make_input(wave):
    rows = [row for row in stimulus((wave, "R0002")) if row[0] == 0]
    layout = json.loads(Path("layouts.json").read_text())["A"]["split_2"]
    used = {node for _, _, _, src, dst, _ in rows for node in (src, dst)}
    assert len(used) == 6 and used == set(layout)
    assert sum(not row[2] for row in rows) == 125
    assert all(src != dst for _, _, _, src, dst, _ in rows)
    return rows


def choose_phase(profile, rows, paths):
    """Apply a predetermined rule to the MoE-only profile, with no CC results."""
    coverage = defaultdict(list)
    cc_edges = set(planner.xy(profile.scenario.cc_src, profile.scenario.cc_dst))
    bypassable = {mid for _, mid, decode, src, dst, _ in rows if decode and (src, dst) in paths}
    for u, v, app, mid, _, time in profile.edges:
        if (u, v) in cc_edges and mid in bypassable:
            coverage[u, v, mid].append(time)
    candidates = [(min(ticks), u, v, mid, max(ticks), len(ticks))
                  for (u, v, mid), ticks in coverage.items()
                  if len(ticks) >= 32 and max(ticks) - min(ticks) >= 32]
    assert candidates, (profile.scenario.wave, coverage)
    first, u, v, mid, last, count = min(candidates)
    return first + 16, dict(u=u, v=v, message=mid, first=first, last=last, flits=count,
                            rule="Earliest bypassable decode frame on the CC request path, plus 16 cycles")


def planned_pair(scenario, rows, paths, work, forecasts):
    base = replay(scenario, rows, work / BASE, mesh_only=True)
    available = [(i, *row) for i, row in enumerate(rows)
                 if base.bindings[row[:2]][0] >= scenario.decision]
    flows = defaultdict(list)
    for i, app, mid, phase, src, dst, release in available:
        flows[app, src, dst].append(i)
    # The fixed Mesh predictor is equivalent to an empty active configuration.
    # A separate validation process repeats the selected RTL plan.
    scores = planner.overlap_scores(base, available, scenario.decision)
    keys = (scenario.cc_src, scenario.cc_dst, scenario.count)
    original = planner.build_pool(flows, available, paths, *keys)
    hot = planner.build_pool(flows, available, paths, *keys, scores=scores) if scores else []
    plan_set = planner.cap_pools(original, hot)

    def predict(plan):
        run = replay(scenario, rows, work / "forecast" / f"{plan.image:x}", plan)
        assert run.prefix_hash == base.prefix_hash
        return run

    with ThreadPoolExecutor(max_workers=3) as pool:
        predicted = dict(zip(plan_set, pool.map(predict, plan_set)))
    selected, checks = planner.new_choice(base, plan_set, predicted)
    trial = replay(scenario, rows, work / DESIGN, selected)
    compare = predicted.get(selected, base)
    assert trial.messages == compare.messages
    assert trial.prefix_hash == base.prefix_hash

    for plan in plan_set:
        reason, gain, guard = checks[plan]
        forecasts.append(dict(case=scenario.name, arm=work.name, cfg=f"{plan.image:x}",
                              routes=[(p.src, p.dst, p.switches) for p in plan.paths],
                              message_ids=[rows[i][1] for i in plan.assignments],
                              predicted_cc_gain=base.cc_step-predicted[plan].cc_step,
                              lower_bound_gain=gain, worst_moe_delta=guard, reason=reason,
                              selected=int(plan == selected)))
    return base, trial, selected, len(plan_set)


def cc_result(outcome):
    return outcome.cc_step - outcome.scenario.cc_start


def export(outcome, case, arm, control, base, probes):
    s = outcome.scenario
    rows = []
    ports = defaultdict(list)
    for mid, seq, u, v, cycle, ready, granted, other in outcome.events["CC_HEAD"]:
        ports[mid, seq, u, v].append((cycle, ready, granted, other))
    for (mid, seq, u, v), samples in ports.items():
        wait = sum(not grant for cycle, ready, grant, other in samples)
        assert sum(grant for cycle, ready, grant, other in samples) == 1
        assert samples[-1][2] == 1
        assert [line[0] for line in samples] == list(range(samples[0][0], samples[-1][0]+1))
        probes.append(dict(case=case, arm=arm, control=control, packet=mid, flit=seq,
                           leg="request" if mid < s.count else "response",
                           src=u, dst=v, head=samples[0][0], grant=samples[-1][0],
                           wait=wait,
                           blocked_by_moe=sum(ready and not grant and other == 0
                                              for cycle, ready, grant, other in samples),
                           backpressure=sum(not ready for cycle, ready, grant, other in samples)))
    for i in range(s.count):
        _, request_release, request_complete = outcome.messages[2, i]
        _, response_release, response_complete = outcome.messages[2, i + s.count]
        assert response_release == request_complete
        old_response = base.messages[2, i + s.count][2]
        req_out = [p for p in probes if (p["case"], p["arm"], p["control"], p["packet"])
                   == (case, arm, control, i)]
        expected = set(planner.xy(s.cc_src, s.cc_dst))
        assert {(p["src"], p["dst"]) for p in req_out} == expected
        rows.append(dict(case=case, arm=arm, control=control, txn=i+1, release=request_release,
                         request_done=request_complete, response_release=response_release,
                         response_done=response_complete, request_latency=request_complete-request_release,
                         response_latency=response_complete-response_release,
                         latency=response_complete-request_release,
                         response_done_delta_same_control=response_complete-old_response,
                         request_head_wait=sum(p["wait"] for p in req_out),
                         request_moe_arbitration_wait=sum(p["blocked_by_moe"] for p in req_out)))
    return rows


def messages(outcome, case, arm, control):
    return [dict(case=case, arm=arm, control=control, app="CC" if app==2 else "MoE", id=mid,
                 decode=d, release=rel, complete=done, bind=outcome.bindings[app,mid][0],
                 plane=outcome.bindings[app,mid][1])
            for (app, mid), (d, rel, done) in sorted(outcome.messages.items())]


def main():
    paths = planner.wired_paths()
    results, txn, msg, probes, forecasts, profile_rules = [], [], [], [], [], []
    solo_cache = {}
    for name, wave, dst, count, externally_fixed in WINDOWS:
        rows = make_input(wave)
        work = ROOT / "single_runs" / name
        profile_key = wave, dst
        if profile_key not in solo_cache:
            s = Scenario(f"solo_{wave}_{dst}", (wave,), 0, dst, 0, "solo", decision=1)
            solo_cache[profile_key] = replay(s, rows, ROOT / "solo" / s.name, mesh_only=True)
        moe = solo_cache[profile_key]
        gate = moe.events["GATE"][0][-1]
        if externally_fixed is None:
            cc_start, anchor = choose_phase(moe, rows, paths)
            profile_rules.append(dict(case=name, cc_start=cc_start, gate=gate, **anchor))
            group = "controlled_overlap"
        else:
            cc_start, group = externally_fixed, "inherited_timing"
        scenario = Scenario(name, (wave,), cc_start, dst, count, group,
                            decision=min(gate, cc_start-64))
        base, full, selected, evaluated = planned_pair(scenario, rows, paths, work/"mixed", forecasts)
        solo_s = replace(scenario, decision=1)
        cc_alone = replay(solo_s, [], work/"cc_alone", mesh_only=True)
        late = moe.metrics["A_all"] + 1024
        staggered = replace(scenario, cc_start=late)
        shifted_b, shifted_full, late_plan, _ = planned_pair(staggered, rows, paths,
                                                              work/"staggered", forecasts)
        assert late_plan == planner.KEEP
        assert cc_result(cc_alone) == cc_result(shifted_b) == cc_result(shifted_full)
        assert {k: v for k, v in shifted_b.messages.items() if k[0] == 0} == moe.messages
        assert shifted_b.messages == shifted_full.messages
        for i in range(count):
            assert {out.messages[2, i][1] for out in (base, full, cc_alone)} == {cc_start+i}
            solo_latency = cc_alone.messages[2, i+count][2] - cc_alone.messages[2, i][1]
            shift_latency = shifted_b.messages[2, i+count][2] - shifted_b.messages[2, i][1]
            assert solo_latency == shift_latency
        for control, arm, run, ref in (("mixed", BASE, base, base), ("mixed", DESIGN, full, base),
                                       ("cc_alone", BASE, cc_alone, cc_alone), ("moe_alone", BASE, moe, moe),
                                       ("staggered", BASE, shifted_b, shifted_b),
                                       ("staggered", DESIGN, shifted_full, shifted_b)):
            txn.extend(export(run, name, arm, control, ref, probes))
            msg.extend(messages(run, name, arm, control))
        joined = [max(run.cc_step, run.metrics["A_all"]) for run in (base, full)]
        result = dict(case=name, wave=wave, category=group, count=count,
                      cc_path=f"0->{dst}", predicted_gate=gate, decision=scenario.decision,
                      cc_start=cc_start, staggered_start=late, evaluated=evaluated,
                      selected=int(selected != planner.KEEP), cfg=f"{selected.image:x}",
                      moe_affected=[rows[i][1] for i in selected.assignments],
                      B_cc_alone=cc_result(cc_alone), B_staggered=cc_result(shifted_b),
                      B_moe_alone_decode=moe.metrics["A_decode"], B_moe_alone_all=moe.metrics["A_all"],
                      B_cc_step=base.cc_step, full_cc_step=full.cc_step,
                      B_join_ready=joined[0], full_join_ready=joined[1],
                      B_last_prerequisite="CC" if base.cc_step >= base.metrics["A_all"] else "MoE",
                      full_last_prerequisite="CC" if full.cc_step >= full.metrics["A_all"] else "MoE")
        for metric, before, after in (("cc_wait", cc_result(base), cc_result(full)),
                                      ("moe_decode", base.metrics["A_decode"], full.metrics["A_decode"]),
                                      ("moe_all", base.metrics["A_all"], full.metrics["A_all"]),
                                      ("join_proxy", joined[0], joined[1])):
            result[f"B_{metric}"] = before
            result[f"full_{metric}"] = after
            result[f"{metric}_cycles_saved"] = before-after
            result[f"{metric}_pct"] = round(100*(before-after)/before, 6)
        result["B_min_CC_delay_vs_solo"] = cc_result(base) - cc_result(cc_alone)
        mixed_req = [p for p in probes if p["case"]==name and p["arm"]==BASE
                     and p["control"]=="mixed" and p["leg"]=="request"]
        true_contention = Counter((p["src"], p["dst"]) for p in mixed_req if p["blocked_by_moe"])
        result["B_direct_request_contention"] = dict((f"{s}->{d}", n) for (s,d),n in true_contention.items())
        results.append(result)
        print(name, group, result["B_cc_wait"], result["full_cc_wait"], result["B_cc_alone"],
              result["B_direct_request_contention"], result["B_last_prerequisite"], flush=True)

    write_csv(ROOT/"single_summary.csv", results)
    write_csv(ROOT/"transactions.csv", txn)
    write_csv(ROOT/"messages.csv", msg)
    write_csv(ROOT/"cc_egress.csv", probes)
    write_csv(ROOT/"decisions.csv", forecasts)
    (ROOT/"alignment.json").write_text(json.dumps(profile_rules, indent=2)+"\n")
    aggregate = []
    for group in ("inherited_timing", "controlled_overlap"):
        items = [r for r in results if r["category"]==group]
        for metric in ("cc_wait", "moe_decode", "moe_all", "join_proxy"):
            values = [r[f"{metric}_pct"] for r in items]
            aggregate.append(dict(group=group, metric=metric, cases=len(values),
                                  improved=sum(v>0 for v in values), unchanged=sum(v==0 for v in values),
                                  regressed=sum(v<0 for v in values),
                                  average_pct=round(statistics.mean(values),6),
                                  min_pct=min(values), max_pct=max(values)))
    write_csv(ROOT/"single_aggregate.csv", aggregate)
    print(f"PASS {len(results)} pairs, {len(txn)} CC transactions, "
          f"{len(msg)} messages, {len(probes)} CC flit-egress records.", flush=True)


if __name__ == "__main__":
    main()

