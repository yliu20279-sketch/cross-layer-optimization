"""Recompute the paired metrics from exported transaction and packet receipts."""

from collections import defaultdict
import csv
import json
from pathlib import Path

import planner


def load(name):
    with open(name, newline="") as stream:
        return list(csv.DictReader(stream))


transactions = defaultdict(dict)
for row in load("transactions.csv"):
    k = row["case"], row["control"], row["arm"]
    assert row["txn"] not in transactions[k]
    assert row["request_done"] == row["response_release"]
    assert int(row["latency"]) == int(row["response_done"]) - int(row["release"])
    transactions[k][row["txn"]] = row

messages = defaultdict(dict)
for row in load("messages.csv"):
    k = row["case"], row["control"], row["arm"]
    mid = row["app"], row["id"]
    assert mid not in messages[k]
    messages[k][mid] = row
    if row["arm"] == "B_mesh":
        assert row["plane"] == "0"

heads = defaultdict(list)
for row in load("cc_egress.csv"):
    assert int(row["wait"]) == int(row["grant"]) - int(row["head"])
    assert int(row["blocked_by_moe"]) + int(row["backpressure"]) <= int(row["wait"])
    heads[row["case"], row["control"], row["arm"]].append(row)

reports = []
rows = load("single_summary.csv")
assert len(rows) == 10
for row in rows:
    case, count = row["case"], int(row["count"])
    source, dest = map(int, row["cc_path"].split("->"))
    baseline_txns = transactions[case, "mixed", "B_mesh"]
    design_txns = transactions[case, "mixed", "B_full"]
    solo_txns = transactions[case, "cc_alone", "B_mesh"]
    shift_txns = transactions[case, "staggered", "B_mesh"]
    for k in baseline_txns:
        assert baseline_txns[k]["release"] == design_txns[k]["release"] == solo_txns[k]["release"]
        assert solo_txns[k]["latency"] == shift_txns[k]["latency"]
    assert len(baseline_txns) == len(design_txns) == len(solo_txns) == len(shift_txns) == count
    keys = {
        "B": (case, "mixed", "B_mesh"),
        "full": (case, "mixed", "B_full"),
    }
    for label, key in keys.items():
        cc_done = max(int(t["response_done"]) for t in transactions[key].values())
        moe_entries = [m for m in messages[key].values() if m["app"] == "MoE"]
        moe_done = max(int(m["complete"]) for m in moe_entries)
        decode_only = [m for m in moe_entries if m["decode"] == "1"]
        decode = max(int(m["complete"]) for m in decode_only) - min(int(m["release"]) for m in decode_only)
        assert cc_done == int(row[label+"_cc_step"])
        assert cc_done - int(row["cc_start"]) == int(row[label+"_cc_wait"])
        assert moe_done == int(row[label+"_moe_all"]) and decode == int(row[label+"_moe_decode"])
        assert max(cc_done, moe_done) == int(row[label+"_join_ready"])
        request_hops = set(planner.xy(source, dest))
        response_hops = set(planner.xy(dest, source))
        assert len(heads[key]) == count*(len(request_hops) + 3*len(response_hops))
        assert {(int(h["src"]), int(h["dst"])) for h in heads[key] if h["leg"]=="request"} == request_hops
        assert {(int(h["src"]), int(h["dst"])) for h in heads[key] if h["leg"]=="response"} == response_hops
    impacted = [t for t in design_txns.values() if int(t["response_done_delta_same_control"])>0]
    reports.append(dict(case=case, later_responses=[int(t["txn"]) for t in impacted],
                        max_later_cycles=max((int(t["response_done_delta_same_control"]) for t in impacted), default=0)))

report = dict(main_pairs=len(rows), mixed_pairs_with_cc_gain=sum(int(r["cc_wait_cycles_saved"])>0 for r in rows),
              transactions=sum(map(len, transactions.values())), messages=sum(map(len, messages.values())),
              probe_records=sum(map(len, heads.values())), transaction_regressions=reports)
Path("independent_audit.json").write_text(json.dumps(report, indent=2)+"\n")
print(json.dumps(report, indent=2))

