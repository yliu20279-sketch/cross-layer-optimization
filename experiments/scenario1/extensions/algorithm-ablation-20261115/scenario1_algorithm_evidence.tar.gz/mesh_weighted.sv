module noc_slot #(parameter W=256)(
  input wire clk, reset,
  input wire [W-1:0] in_data,
  input wire in_valid, out_ready,
  output wire in_ready,
  output reg [W-1:0] out_data,
  output reg out_valid
);
  // Registered occupancy cuts both the data and the backpressure paths.
  assign in_ready=!reset && !out_valid;
  always @(posedge clk) begin
    if(reset) begin
      out_valid<=0;
      out_data<=0;
    end else if(in_ready && in_valid) begin
      out_valid<=1;
      out_data<=in_data;
    end else if(out_ready) out_valid<=0;
  end
endmodule

module mesh_router #(parameter W=256, ID=0, WEIGHTED=0)(
  input wire clk, reset,
  input wire [5*(W+4)-1:0] in_flit,
  input wire [4:0] in_valid, out_ready,
  output wire [4:0] in_ready,
  output reg [4:0] out_valid,
  output reg [5*(W+4)-1:0] out_flit
);
  // Ports E, W, N (+row), S (-row), local.
  localparam F=W+4;
  wire [4:0][F-1:0] queued;
  wire [4:0] full;
  reg [4:0] pop;
  reg [2:0] next_first [0:4], first [0:4];
  reg [4:0] locked, next_locked;
  integer turn;
  always @(posedge clk)
    if(reset) turn<=0;
    else if(WEIGHTED && ID==5 && out_valid[2] && out_ready[2])
      turn<=turn==2 ? 0 : turn+1;
  function automatic [2:0] route(input [3:0] d);
    if(d[1:0]>(ID%4)) route=0;
    else if(d[1:0]<(ID%4)) route=1;
    else if(d[3:2]>(ID/4)) route=2;
    else if(d[3:2]<(ID/4)) route=3;
    else route=4;
  endfunction
  for(genvar p=0;p<5;p=p+1) begin: queues
    noc_slot #(.W(F)) q(clk,reset,in_flit[p*F+:F],in_valid[p],pop[p],
      in_ready[p],queued[p],full[p]);
    always @(posedge clk)
      if(reset) begin first[p]<=0; locked[p]<=0; end else begin first[p]<=next_first[p]; locked[p]<=next_locked[p]; end
  end
  wire [4:0] grant [0:4];
  for(genvar port=0;port<5;port=port+1) begin: arb
    integer k, i, chosen;
    reg has_preferred;
    always_comb begin
      has_preferred=0;
      for(int a=0;a<5;a++)
        if(full[a] && route(queued[a][W+:4])==port && queued[a][64]==(turn==2))
          has_preferred=1;
      chosen=-1;
      for(k=0;k<5;k++) begin
        i=(int'(first[port])+k)%5;
        if(chosen<0 && (!locked[port] || k==0) && full[i] &&
           route(queued[i][W+:4])==port &&
           (locked[port] || !WEIGHTED || ID!=5 || port!=2 || !has_preferred ||
            queued[i][64]==(turn==2))) chosen=i;
      end
    end
    assign out_valid[port]=chosen>=0;
    assign out_flit[port*F+:F]=chosen>=0 ? queued[chosen] : '0;
    assign grant[port]=(chosen>=0 && out_ready[port]) ? 5'b1<<chosen : 0;
    assign next_first[port]=chosen<0 ? first[port] :
      out_ready[port] ? (chosen+1)%5 : chosen;
    assign next_locked[port]=chosen>=0 && !out_ready[port];
  end
  assign pop=grant[0]|grant[1]|grant[2]|grant[3]|grant[4];
endmodule

module mesh16 #(parameter W=256, WEIGHTED=0)(
  input wire clk, reset,
  input wire [16*(W+4)-1:0] tx_data,
  input wire [15:0] tx_valid, rx_ready,
  output wire [15:0] tx_ready, rx_valid,
  output wire [16*W-1:0] rx_data
);
  localparam F=W+4;
  wire [15:0][5*F-1:0] in_flit, out_flit;
  wire [15:0][4:0] iv, ir, ov, rd;
  for(genvar n=0;n<16;n=n+1) begin: routers
    for(genvar p=0;p<4;p=p+1) begin: links
      localparam PEER=p==0 ? n+1 : p==1 ? n-1 : p==2 ? n+4 : n-4;
      localparam OPP=p^1;
      localparam CONNECTED=p==0 ? n%4!=3 : p==1 ? n%4!=0 : p==2 ? n/4!=3 : n/4!=0;
      if(CONNECTED) begin
        assign in_flit[n][p*F+:F]=out_flit[PEER][OPP*F+:F];
        assign iv[n][p]=ov[PEER][OPP];
        assign rd[n][p]=ir[PEER][OPP];
      end else begin
        assign in_flit[n][p*F+:F]=0;
        assign iv[n][p]=0;
        assign rd[n][p]=0;
      end
    end
    assign in_flit[n][4*F+:F]=tx_data[n*F+:F];
    assign iv[n][4]=tx_valid[n];
    assign tx_ready[n]=ir[n][4];
    assign rx_data[n*W+:W]=out_flit[n][4*F+:W];
    assign rx_valid[n]=ov[n][4];
    assign rd[n][4]=rx_ready[n];
    mesh_router #(.W(W),.ID(n),.WEIGHTED(WEIGHTED)) r(clk,reset,in_flit[n],iv[n],rd[n],ir[n],ov[n],out_flit[n]);
  end
endmodule


