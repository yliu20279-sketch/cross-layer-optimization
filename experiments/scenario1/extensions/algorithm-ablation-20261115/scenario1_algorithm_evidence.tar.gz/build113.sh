#!/usr/bin/env bash
set -eu
cd "$(dirname "$0")"
python3 prepare.py
mkdir -p tmp
toolchain="$(realpath "${VERILATOR_TREE:-vl}")"
docker run --rm --network none --log-driver none --read-only \
  --user "$(id -u):$(id -g)" -v "$PWD:/work" -v "$toolchain:/tool:ro" -w /work \
  -e TMPDIR=/work/tmp -e VERILATOR_ROOT=/tool/usr/share/verilator \
  --entrypoint /tool/usr/bin/verilator ub-pim:24.04 \
  --binary --timing -j 8 -Wno-fatal --top-module unified_tb -GWEIGHTED=1 \
  --Mdir obj mesh_weighted.sv aux_packed.sv experiment_tb.sv > build.log 2>&1

