"""Instrument the existing RTL harness; leave both interconnect modules intact."""
from pathlib import Path


def replace_once(source, before, after):
    assert source.count(before) == 1, before
    return source.replace(before, after)


def main():
    source = Path("base_tb.sv").read_text()
    edits = [
        ("[276]", "[300]"),
        (" integer rtl_done[300];", """ integer rtl_done[300];
 integer phase[300], plane[300], planned[300];
 integer app_count, change_at, seed_app, seed_id, seed_index=-1, seed_cycle, seed_flag=0;
 integer cc_src, cc_dst, cfg_stage=0, aux_pending=0, aux_last_bank=0, last_ready=-1;
 integer cmd_file, cmd_result, selected, total_prefill=0;
 reg [77:0] old_image, next_image;
 reg other_grant;
 function automatic bit ends_on_cc_request(input integer j);
  ends_on_cc_request=app[j]==2 && id[j]<cc_count;
 endfunction
 function automatic bit send_aux(input integer j);
  send_aux=plane[j]>0 || (plane[j]<0 && ((j==seed_index && cfg_stage==1) ||
           (planned[j] && mode==2 && cfg_stage==2 && c>=last_ready)));
 endfunction
 function automatic bit xy_edge(input integer u, input integer v, input integer start, input integer stop);
  integer x, y, tx, ty, here, next_hop, k;
  begin
   x=start%4; y=start/4; tx=stop%4; ty=stop/4; xy_edge=0;
   for(k=0;k<6;k++) begin
    here=4*y+x;
    if(x<tx) x++; else if(x>tx) x--; else if(y<ty) y++; else if(y>ty) y--;
    next_hop=4*y+x;
    if(here==u && next_hop==v && here!=next_hop) xy_edge=1;
   end
  end
 endfunction"""),
        ("diverted=mode!=0 && app[j]==0 && (id[j]==158 || id[j]==159);",
         "diverted=send_aux(j);"),
        ('  nframes=(active ? 260 : 0)+2*cc_count;', """  if(!$value$plusargs("decision=%d",change_at)) change_at=16462;
  if(!$value$plusargs("seedapp=%d",seed_app)) seed_app=-1;
  if(!$value$plusargs("seedid=%d",seed_id)) seed_id=-1;
  if(!$value$plusargs("seedcycle=%d",seed_cycle)) seed_cycle=16400;
  if(!$value$plusargs("ccsrc=%d",cc_src)) cc_src=0;
  if(!$value$plusargs("ccdst=%d",cc_dst)) cc_dst=9;
  if(!$value$plusargs("packets=%d",app_count)) app_count=260;
  cmd_file=$fopen("plan.stim","r");
  if(!cmd_file || $fscanf(cmd_file,"%h %h",old_image,next_image)!=2) $fatal(1,"missing config images");
  nframes=(active ? app_count : 0)+2*cc_count;
  if(nframes>300 || cc_src==cc_dst) $fatal;"""),
        ("for(i=0;i<260 && active;i++)", "for(i=0;i<app_count && active;i++)"),
        ("""   if(dec[i] && rel[i]<phase_origin[app[i]]) phase_origin[app[i]]=rel[i];
   if(!dec[i]) pre_left[app[i]]++;
   sent[i]=0; issued[i]=0; got[i]=0; len[i]=132; rtl_done[i]=-1;
   if(diverted(i)) expected_cs+=len[i];
   if(diverted(i) && (src[i]!=4 || dst[i]!=9 || !dec[i])) $fatal;""",
         """   if(dec[i] && rel[i]<phase_origin[app[i]]) phase_origin[app[i]]=rel[i];
   if(app[i]==seed_app && id[i]==seed_id) begin
    if(dec[i]) $fatal;
    seed_index=i;
    seed_flag=1;
    rel[i]=seed_cycle;
   end else if(!dec[i]) pre_left[app[i]]++;
   sent[i]=0; issued[i]=0; got[i]=0; len[i]=132; rtl_done[i]=-1;
   plane[i]=-1; planned[i]=0;
   if(!dec[i]) total_prefill++;
   end
  while(!$feof(cmd_file)) begin
   cmd_result=$fscanf(cmd_file,"%d",selected);
   if(cmd_result==1) begin
    if(selected<0 || selected>=app_count || selected==seed_index) $fatal;
    planned[selected]=1;
   end
  end
  $fclose(cmd_file);
  if(seed_flag != (|old_image)) $fatal;
  begin"""),
        ("for(i=(active ? 260 : 0);i<nframes;i++)", "for(i=(active ? app_count : 0);i<nframes;i++)"),
        ("id[i]=i-(active ? 260 : 0);", "id[i]=i-(active ? app_count : 0);"),
        ("src[i]=id[i]<cc_count ? 0 : 9; dst[i]=id[i]<cc_count ? 9 : 0;",
         "src[i]=id[i]<cc_count ? cc_src : cc_dst; dst[i]=id[i]<cc_count ? cc_dst : cc_src;"),
        ("len[i]=id[i]<cc_count ? 1 : 3; sent[i]=0; issued[i]=0; got[i]=0;",
         "len[i]=id[i]<cc_count ? 1 : 3; sent[i]=0; issued[i]=0; got[i]=0; plane[i]=-1; planned[i]=0;"),
        ("for(int j=0;j<260;j++)", "for(int j=0;j<app_count;j++)"),
        ("""   if(mode==2 && config_start<0 && active && ((indep && gates[0]>=0) || (!indep && c>=phase_origin[0]))) begin
    config_start=c;
    $display("CFG_TRIGGER,%0d,%0d",c,cr);
   end
   cv=commit<0 && (mode==1 || (mode==2 && config_start>=0 && c>=config_start+ctrl));
   if(cv && cr && cfg_tick<0) begin cfg_tick=c; $display("CFG_ACCEPT,%0d",c); end
   cfg[18+:6]=6'b100101;""",
         """   if(c==change_at) begin
    $display("SNAP,%0d,%0d,%0d,%0d,%0h",c,gates[0],gates[1],aux_pending,cs.occupied);
    if(mode==2) begin
     config_start=c;
     $display("CFG_TRIGGER,%0d,%0d,%0h",c,aux_pending,cs.occupied);
    end
   end
   cv=0;
   if(cfg_stage==0) begin
    cfg=old_image; cv=1;
   end else if(cfg_stage==1 && config_start>=0) begin
    if(aux_pending==0 && c>=aux_last_bank && committed_cfg==0) begin
     $display("DRAIN,%0d",c);
     committed_cfg=1;
    end
    if(committed_cfg && c>=config_start+ctrl) begin
     cfg=next_image; cv=1;
    end
   end
   if(cv && cr && cfg_stage==1 && cfg_tick<0) begin
    cfg_tick=c;
    $display("CFG_ACCEPT,%0d",c);
   end
   if(cfg_stage==2 && c==last_ready) $display("INSTALL_READY,%0d",c);"""),
        ("""       if(app[q]<2 && !dec[q]) begin""",
         """       if(plane[q]) begin
        aux_pending--;
        if(rtl_done[q]>aux_last_bank) aux_last_bank=rtl_done[q];
       end
       if(app[q]<2 && !dec[q] && q!=seed_index) begin"""),
        ("""       (!diverted(i) || (commit>=0 && c>=commit+(mode==2 ? install : 0)))) begin""",
         """       (!(planned[i] && mode==2 && c>=change_at && plane[i]<0)
        || (cfg_stage==2 && c>=last_ready))) begin"""),
        ("      fifo_msg[n][tail[n]]=q;", """      if(plane[q]<0) begin
       plane[q]=send_aux(q);
       if(plane[q]) aux_pending++;
       $display("BIND,%0d,%0d,%0d,%0d",app[q],id[q],c,plane[q]);
      end
      fifo_msg[n][tail[n]]=q;"""),
        ("    sent[q]++; head[n]", """    if(q==seed_index && sent[q]==0) $display("SEED_TX,%0d,%0d",c,plane[q]);
    sent[q]++; head[n]"""),
        ("""   if(mesh.ov[5][2]) begin
    payload=mesh.out_flit[5][2*69+:65]; q=payload[63:32];
    if(watch(q)) $display("FLOW,LINK,%0d,%0d,%0d,%0d,%0d",app[q],id[q],payload[31:0],c,mesh.rd[5][2]);
   end""",
         """   for(int u=0;u<16;u++) for(int op=0;op<4;op++) begin
    int v;
    v=op==0 ? u+1 : op==1 ? u-1 : op==2 ? u+4 : u-4;
    if(mesh.ov[u][op] && (xy_edge(u,v,cc_src,cc_dst) || xy_edge(u,v,cc_dst,cc_src))) begin
     payload=mesh.out_flit[u][op*69+:65]; q=payload[63:32];
     if(mesh.rd[u][op])
      $display("EDGE,%0d,%0d,%0d,%0d,%0d,%0d",u,v,app[q],id[q],payload[31:0],c);
    end
   end"""),
        ("""   if(applied) begin commit=c; $display("COMMIT,%0d",c); end
  end
  if(g!=nframes || total!=(active ? 34320 : 0)+4*cc_count || cs_count!=expected_cs || rsp_left!=0 || (mode!=0 && commit<0)) $fatal(1,"counts %0d %0d",total,cs_count);""",
         """   if(applied) begin
    if(cfg_stage==0) begin
     $display("INITIAL,%0d,%0h",c,old_image);
     cfg_stage=1;
    end else begin
     cfg_stage=2; commit=c; last_ready=c+install;
     $display("COMMIT,%0d,%0h",c,next_image);
    end
   end
  end
  if(g!=nframes || total!=(active ? app_count*132 : 0)+4*cc_count || aux_pending!=0 ||
     rsp_left!=0 || (mode==2 && commit<0) || (seed_flag && plane[seed_index]!=1))
      $fatal(1,"counts %0d %0d",total,cs_count);"""),
    ]
    source = source.replace(*edits[0])
    for before, after in edits[1:]:
        if before != after:
            source = replace_once(source, before, after)
    # The previous test's 5->9 probe was tied to NI9. EDGE above covers the active CC path.
    begin = source.index("   for(int p=0;p<5;p++) begin\n    if(mesh.routers[5]")
    end = source.index("   for(int u=0;u<16;u++)", begin)
    source = source[:begin] + source[end:]
    source = source.replace('if(watch(q)) $display("FLOW,', 'if(app[q]==2) $display("FLOW,')
    Path("experiment_tb.sv").write_text(source)


if __name__ == "__main__":
    main()

