module unified_tb;
 parameter WEIGHTED=0;
 reg clk=0; always #5 clk=~clk;
 reg reset=1, cv=0;
 reg [77:0] cfg=0;
 wire cr,applied,rejected;
 reg [1103:0] md=0;
 reg [1039:0] ad=0;
 wire [1039:0] mo,ao;
 reg [15:0] mv=0,av=0,mrr=0,arr=0;
 wire [15:0] mr,ar,mrv,arv;
 mesh16 #(.W(65),.WEIGHTED(WEIGHTED)) mesh(clk,reset,md,mv,mrr,mr,mrv,mo);
 aux13 #(.W(65)) cs(clk,reset,cv,cfg,cr,applied,rejected,ad,av,arr,ar,arv,ao);
 integer app[276], id[276], dec[276], src[276], dst[276], rel[276];
 integer sent[276], got[276], free_at[16][8], pick[16], read_bank[16], read_at[16], read_msg[16];
 integer priority_on, active_msg[16], owe_prefill[16], decode_pick[16], prefill_pick[16];
 integer depth, issued[276], head[16], tail[16], occupancy[16], fifo_msg[16][8], fifo_at[16][8], peak=0;
 integer mode, bank_cycles, ctrl, install, f,i,n,b,c,q,g=0,total=0,commit=-1,cs_count=0;
 integer a_grants=0,b_grants=0;
 integer active, cc_count, cc_start, cc_policy, indep, delay_a, b_offset, config_start=-1, cfg_tick=-1;
 integer nframes, len[276], pre_left[2], pre_done[2], gates[2], phase_origin[2];
 integer rsp_ready[8], rsp_left, cc_step=-1, expected_cs=0, committed_cfg=0;
 integer rtl_done[276];
 function automatic bit ready_at(input integer j);
  if(app[j]==2) ready_at=c>=rel[j];
  else if(indep && dec[j]) ready_at=gates[app[j]]>=0 && c>=rel[j];
  else ready_at=c>=rel[j];
 endfunction

 reg [64:0] payload;
 function automatic bit diverted(input integer j);
  diverted=mode!=0 && app[j]==0 && (id[j]==158 || id[j]==159);
 endfunction
 function automatic integer bank(input integer j,input integer seq_id);
  bank=(id[j]+seq_id)%8;
 endfunction
 function automatic bit watch(input integer j); watch=app[j]==2 || src[j]==4 || src[j]==1; endfunction
 initial begin
  if(!$value$plusargs("mode=%d",mode) || !$value$plusargs("bank=%d",bank_cycles) ||
     !$value$plusargs("ctrl=%d",ctrl) || !$value$plusargs("install=%d",install)) $fatal;
  if(!$value$plusargs("priority=%d",priority_on)) priority_on=0;
  if(!$value$plusargs("depth=%d",depth) || depth<1 || depth>8) $fatal;
  if(bank_cycles<1 || ctrl<1 || install<1 || (mode==1 && !WEIGHTED)) $fatal;
  if(!$value$plusargs("active=%d",active)) active=1;
  if(!$value$plusargs("cc=%d",cc_count)) cc_count=0;
  if(!$value$plusargs("ccstart=%d",cc_start)) cc_start=17000;
  if(!$value$plusargs("ccpolicy=%d",cc_policy)) cc_policy=0;
  if(!$value$plusargs("indep=%d",indep)) indep=1;
  if(!$value$plusargs("delay_a=%d",delay_a)) delay_a=0;
  if(!$value$plusargs("b_offset=%d",b_offset)) b_offset=0;
  if(cc_count<0 || cc_count>8 || mode<0 || mode>2) $fatal;
  for(i=0;i<2;i++) begin
   pre_left[i]=0; pre_done[i]=-1; gates[i]=-1; phase_origin[i]=999999;
  end
  nframes=(active ? 260 : 0)+2*cc_count;
  rsp_left=cc_count;
  f=$fopen("unified.stim","r");
  for(i=0;i<260 && active;i++) begin
   if($fscanf(f,"%d %d %d %d %d %d",app[i],id[i],dec[i],src[i],dst[i],rel[i])!=6) $fatal;
   if(app[i]==1) rel[i]+=b_offset;
   if(dec[i] && rel[i]<phase_origin[app[i]]) phase_origin[app[i]]=rel[i];
   if(!dec[i]) pre_left[app[i]]++;
   sent[i]=0; issued[i]=0; got[i]=0; len[i]=132; rtl_done[i]=-1;
   if(diverted(i)) expected_cs+=len[i];
   if(diverted(i) && (src[i]!=4 || dst[i]!=9 || !dec[i])) $fatal;
  end
  $fclose(f);
  for(i=(active ? 260 : 0);i<nframes;i++) begin
   app[i]=2; id[i]=i-(active ? 260 : 0); dec[i]=0;
   src[i]=id[i]<cc_count ? 0 : 9; dst[i]=id[i]<cc_count ? 9 : 0;
   rel[i]=id[i]<cc_count ? cc_start+id[i] : 1000000;
   len[i]=id[i]<cc_count ? 1 : 3; sent[i]=0; issued[i]=0; got[i]=0; rtl_done[i]=-1;
  end
  for(n=0;n<16;n++) begin
   head[n]=0; tail[n]=0; occupancy[n]=0; active_msg[n]=-1; owe_prefill[n]=0;
   for(b=0;b<8;b++) free_at[n][b]=0;
  end
  repeat(2) @(negedge clk); reset=0;
  for(c=0;c<150000 && g<nframes;c++) begin
   #1;
   if(c<=8) $display("RXTRACE,%0d,%b,%h,%h,%h",c,mrv[0],mesh.out_flit[0][4*69+:69],mo[0+:65],mesh.routers[0].r.full);
   for(int a=0;a<2;a++) begin
    if(active && indep && gates[a]<0 && pre_done[a]>=0 &&
       c>=pre_done[a]+(a==0 ? delay_a : 0)) begin
     gates[a]=c;
     $display("GATE,%0d,%0d,%0d",a,pre_done[a],c);
     for(int j=0;j<260;j++) if(app[j]==a && dec[j]) rel[j]=c+rel[j]-phase_origin[a];
    end
   end
   if(mode==2 && config_start<0 && active && ((indep && gates[0]>=0) || (!indep && c>=phase_origin[0]))) begin
    config_start=c;
    $display("CFG_TRIGGER,%0d,%0d",c,cr);
   end
   cv=commit<0 && (mode==1 || (mode==2 && config_start>=0 && c>=config_start+ctrl));
   if(cv && cr && cfg_tick<0) begin cfg_tick=c; $display("CFG_ACCEPT,%0d",c); end
   cfg[18+:6]=6'b100101;
   mv=0; av=0; mrr=0; arr=0;
   for(n=0;n<16;n++) begin
    pick[n]=-1; decode_pick[n]=-1; prefill_pick[n]=-1;
    read_bank[n]=-1;
   end
   // Destination writes have priority. Each NI accepts one flit per cycle.
   for(n=0;n<16;n++) begin
    if(mrv[n] || arv[n]) begin
     payload=mrv[n] ? mo[n*65+:65] : ao[n*65+:65];
     q=payload[63:32];
     if(q<0 || q>=nframes || dst[q]!=n || payload[31:0]!=got[q] ||
        diverted(q)!=!mrv[n]) $fatal(1,"bad RX at %0d node %0d q %0d dest %0d seq %0d got %0d mesh %b aux %b",c,n,q,dst[q],payload[31:0],got[q],mrv[n],arv[n]);
     b=bank(q,got[q]);
     if(watch(q)) $display("FLOW,RX,%0d,%0d,%0d,%0d,%0d",app[q],id[q],got[q],c,c>=free_at[n][b]);
     if(c>=free_at[n][b]) begin
      if(mrv[n]) mrr[n]=1; else begin arr[n]=1; cs_count++; end
      free_at[n][b]=c+bank_cycles;
      got[q]++; total++;
      if(got[q]==len[q]) begin
       g++; rtl_done[q]=c+bank_cycles;
       $display("DONE,%0d,%0d,%0d,%0d,%0d",app[q],id[q],dec[q],rel[q],rtl_done[q]);
       if(app[q]<2 && !dec[q]) begin
        pre_left[app[q]]--;
        if(pre_left[app[q]]==0) pre_done[app[q]]=rtl_done[q];
       end
       if(app[q]==2 && id[q]<cc_count) begin
        rel[q+cc_count]=rtl_done[q];
        $display("RESPONSE_RELEASE,%0d,%0d",id[q],rel[q+cc_count]);
       end
       if(app[q]==2 && id[q]>=cc_count) begin
        rsp_left--;
        if(rsp_left==0) begin cc_step=rtl_done[q]; $display("CC_STEP,%0d",cc_step); end
       end
      end
     end
    end
   end
   // One pending source read per NI, shared by both planes.
   for(i=0;i<nframes;i++) begin
    n=src[i];
    if(ready_at(i) && sent[i]<len[i] &&
       (!diverted(i) || (commit>=0 && c>=commit+(mode==2 ? install : 0)))) begin
     if(pick[n]<0) pick[n]=i;
     if(app[i]==2 && cc_policy) pick[n]=i;
     if(app[i]<2 && dec[i] && decode_pick[n]<0) decode_pick[n]=i;
     if(app[i]<2 && !dec[i] && prefill_pick[n]<0) prefill_pick[n]=i;
    end
   end
   for(n=0;n<16;n++) begin
    if(priority_on && !(pick[n]>=0 && app[pick[n]]==2)) begin
     if(active_msg[n]>=0) pick[n]=active_msg[n];
     else if(owe_prefill[n] && prefill_pick[n]>=0) pick[n]=prefill_pick[n];
     else if(decode_pick[n]>=0) pick[n]=decode_pick[n];
    end
    if(occupancy[n]<depth && pick[n]>=0 && issued[pick[n]]<len[pick[n]]) begin
     q=pick[n]; b=bank(q,issued[q]);
     if(watch(q)) $display("FLOW,READ,%0d,%0d,%0d,%0d,%0d",app[q],id[q],issued[q],c,c>=free_at[n][b]);
     if(c>=free_at[n][b]) begin
      free_at[n][b]=c+bank_cycles;
      if(priority_on && active_msg[n]<0 && app[q]<2) begin
       active_msg[n]=q;
       owe_prefill[n]=dec[q] && prefill_pick[n]>=0;
       $display("SCHED,%0d,%0d,%0d,%0d,%0d,%0d",n,app[q],id[q],dec[q],c,owe_prefill[n]);
      end
      fifo_msg[n][tail[n]]=q;
      fifo_at[n][tail[n]]=c+bank_cycles;
      tail[n]=(tail[n]+1)%8; occupancy[n]++; issued[q]++;
      if(occupancy[n]>peak) peak=occupancy[n];
     end
    end
    q=fifo_msg[n][head[n]];
    if(occupancy[n]>0 && c>=fifo_at[n][head[n]]) begin
     payload=0; payload[64]=app[q][0]; payload[63:32]=q; payload[31:0]=sent[q];
     if(diverted(q)) begin av[n]=1; ad[n*65+:65]=payload; end
     else begin mv[n]=1; md[n*69+:69]={dst[q][3:0],payload}; end
    end
   end
   #1;
   for(n=0;n<16;n++) if((mv[n] && mr[n]) || (av[n] && ar[n])) begin
    if(c<=8) $display("TXTRACE,%0d,%0d,%h",c,n,md[n*69+:69]);
    q=fifo_msg[n][head[n]];
    if(watch(q)) $display("FLOW,TX,%0d,%0d,%0d,%0d,1",app[q],id[q],sent[q],c);
    sent[q]++; head[n]=(head[n]+1)%8; occupancy[n]--;
    if(priority_on && sent[q]==len[q] && app[q]<2) active_msg[n]=-1;
    if(app[q]<2 && dec[q]) begin
     if(indep && (gates[app[q]]<0 || c<gates[app[q]])) $fatal(1,"early decode");
     if(sent[q]==1) $display("DECODE_TX,%0d,%0d,%0d",app[q],id[q],c);
    end
   end
   for(int p=0;p<5;p++) begin
    if(mesh.routers[5].r.full[p] && mesh.routers[5].r.queued[p][68:65]==4'd9) begin
     q=mesh.routers[5].r.queued[p][63:32];
     if(app[q]==2) begin
      $display("CC_HEAD,%0d,%0d,%0d,%0d,%0d",
               id[q],c,p,mesh.rd[5][2],mesh.routers[5].r.arb[2].chosen);
     end
    end
   end
   if(mesh.ov[5][2]) begin
    payload=mesh.out_flit[5][2*69+:65]; q=payload[63:32];
    if(watch(q)) $display("FLOW,LINK,%0d,%0d,%0d,%0d,%0d",app[q],id[q],payload[31:0],c,mesh.rd[5][2]);
   end
   if(mesh.ov[5][2] && mesh.rd[5][2]) begin
    if(mesh.out_flit[5][2*69+64]) b_grants++; else a_grants++;
   end
   @(negedge clk);
   if(rejected) $fatal;
   if(applied) begin commit=c; $display("COMMIT,%0d",c); end
  end
  if(g!=nframes || total!=(active ? 34320 : 0)+4*cc_count || cs_count!=expected_cs || rsp_left!=0 || (mode!=0 && commit<0)) $fatal(1,"counts %0d %0d",total,cs_count);
  $display("DEPTH,%0d,%0d",depth,peak);
  $display("PASS,%0d,%0d,%0d,%0d,%0d",mode,total,cs_count,a_grants,b_grants);
  $finish;
 end
endmodule








