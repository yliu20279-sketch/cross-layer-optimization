"""Evaluate bounded policies and replay only their selected RTL plans on 113."""

import argparse
from collections import Counter, defaultdict
from concurrent.futures import ThreadPoolExecutor
import csv
from dataclasses import dataclass, replace
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

import planner


ROOT = Path.cwd()
ARMS = ("original", "candidate_only", "submit_only", "both")


@dataclass(frozen=True)
class Scenario:
    name: str
    wave: tuple
    cc_start: int
    cc_dst: int
    count: int = 8
    kind: str = "holdout"
    decision: int = 16462
    seed: tuple = ()
    cc_src: int = 0
    actual_cc_offset: int = 0


SCENARIOS = (
    Scenario("dev_single", ("R0002", "R0002"), 17803, 9, 1, "development"),
    Scenario("dev_burst", ("R0002", "R0002"), 17803, 9, kind="development"),
    Scenario("hold_r7_early", ("R0007", "R0007"), 17175, 8),
    Scenario("hold_r7_main", ("R0007", "R0007"), 17803, 8),
    Scenario("hold_r10_main", ("R0010", "R0010"), 17803, 9),
    Scenario("hold_r14_main", ("R0014", "R0014"), 17803, 8),
    Scenario("hold_mixed", ("R0007", "R0010"), 18125, 9),
    Scenario("hold_r7_offset", ("R0007", "R0007"), 17803, 8, kind="forecast_offset", actual_cc_offset=19),
    Scenario("hold_r10_offset", ("R0010", "R0010"), 17803, 9, kind="forecast_offset", actual_cc_offset=-23),
    Scenario("shift_dev", ("R0002", "R0002"), 25000, 9, kind="staggered"),
    Scenario("shift_r7", ("R0007", "R0007"), 25000, 8, kind="staggered"),
    Scenario("busy_dev", ("R0002", "R0002"), 17803, 9, kind="busy"),
    Scenario("busy_r7", ("R0007", "R0007"), 17803, 8, kind="busy"),
    Scenario("busy_r10", ("R0010", "R0010"), 17803, 9, kind="busy"),
)


def stimulus(wave):
    original = [tuple(map(int, line.split())) for line in Path("unified.stim").read_text().splitlines()]
    layout = json.loads(Path("layouts.json").read_text())
    memberships = [layout["A"]["split_2"], layout["B_new"]]
    routes = json.loads(Path("decode_routes.json").read_text())
    for a, request in enumerate(wave):
        if request == "R0002":
            continue
        phase_base = min(t for app, _, d, _, _, t in original if app == a and d)
        original = [p for p in original if p[0] != a or not p[2]]
        region = memberships[a]
        owners = routes[request]["owners"]
        original += [(a, 152 + slot, 1, region[0], region[owner % 6], phase_base + slot * 17)
                     for slot, owner in enumerate(owners) if owner % 6 != 0]
    assert len({(a, mid) for a, mid, *_ in original}) == len(original)
    assert sum(not d for a, mid, d, s, t, r in original) == 250
    for i, nodes in enumerate(memberships):
        used = {node for a, _, _, src, dst, _ in original if a == i for node in (src, dst)}
        assert used == set(nodes) and len(used) == 6
    return original


@dataclass
class Outcome:
    scenario: Scenario
    messages: dict
    bindings: dict
    edges: list
    flow: list
    events: dict
    prefix_hash: str
    path: Path

    @property
    def cc_step(self):
        return self.events["CC_STEP"][0][0]

    @property
    def metrics(self):
        stats = {}
        for app, label in ((0, "A"), (1, "B")):
            all_items = [value for key, value in self.messages.items() if key[0] == app]
            stats[f"{label}_all"] = max(done for d, rel, done in all_items)
            stats[f"{label}_pref"] = max(done for d, rel, done in all_items if not d)
            decode = [(rel, done) for d, rel, done in all_items if d]
            stats[f"{label}_decode"] = max(done for rel, done in decode) - min(rel for rel, done in decode)
            stats[f"{label}_decode_end"] = max(done for _, done in decode)
        return stats

    @property
    def wave_done(self):
        return max(self.metrics[key] for key in ("A_decode_end", "B_decode_end"))


def replay(scenario, rows, directory, plan=planner.KEEP):
    directory.mkdir(parents=True, exist_ok=True)
    (directory / "unified.stim").write_text("".join(" ".join(map(str, row)) + "\n" for row in rows))
    old_image = scenario.seed[2] if scenario.seed else 0
    (directory / "plan.stim").write_text(f"{old_image:x} {plan.image:x}\n"
                                         + "".join(f"{i}\n" for i in plan.assignments))
    args = dict(mode=0 if plan == planner.KEEP else 2, bank=4, ctrl=32, install=8, priority=1,
                depth=4, cc=scenario.count, ccstart=scenario.cc_start, ccsrc=scenario.cc_src,
                ccdst=scenario.cc_dst, decision=scenario.decision, packets=len(rows))
    if scenario.seed:
        args.update(seedapp=scenario.seed[0], seedid=scenario.seed[1], seedcycle=16400)
    (directory / "args.json").write_text(json.dumps(args, indent=2) + "\n")
    relpath = directory.relative_to(ROOT)
    cmd = ["docker", "run", "--rm", "--network", "none", "--read-only", "--log-driver", "none",
           "--user", f"{os.getuid()}:{os.getgid()}", "-v", f"{ROOT}:/work", "-w", f"/work/{relpath}",
           "--entrypoint", "/work/obj/Vunified_tb", "ub-pim:24.04"]
    with (directory / "rtl.log").open("w") as log:
        subprocess.run(cmd + [f"+{k}={v}" for k, v in args.items()], stdout=log,
                       stderr=subprocess.STDOUT, check=True, timeout=75)
    messages, binds, edges, flow, events = {}, {}, [], [], defaultdict(list)
    prefix = hashlib.sha256()
    for original in (directory / "rtl.log").read_text().splitlines():
        line = original.strip()
        fields = line.split(",")
        tag = fields[0]
        if tag == "DONE":
            a, mid, d, release, done = map(int, fields[1:])
            assert (a, mid) not in messages and release <= done
            messages[a, mid] = d, release, done
            if done < scenario.decision:
                prefix.update(line.encode())
        elif tag == "BIND":
            a, mid, tick, plane = map(int, fields[1:])
            assert (a, mid) not in binds
            binds[a, mid] = tick, plane
            if tick < scenario.decision:
                prefix.update(line.encode())
        elif tag == "EDGE":
            edges.append(tuple(map(int, fields[1:])))
            if edges[-1][-1] < scenario.decision:
                prefix.update(line.encode())
        elif tag == "FLOW" and fields[1] in ("RX", "TX"):
            flow.append((fields[1], *map(int, fields[2:])))
        elif tag in ("CFG_TRIGGER", "SNAP", "COMMIT"):
            events[tag].append(tuple(int(f, 16 if i == len(fields)-2 else 10)
                                     for i, f in enumerate(fields[1:])))
        elif tag in ("CC_STEP", "DRAIN", "INSTALL_READY", "SEED_TX", "CFG_ACCEPT", "PASS", "GATE"):
            events[tag].append(tuple(map(int, fields[1:])))
    assert len(events["PASS"]) == len(events["SNAP"]) == 1
    assert len(messages) == len(binds) == len(rows) + 2 * scenario.count
    for i in range(scenario.count):
        assert messages[2, i][2] == messages[2, i + scenario.count][1]
    assert max(messages[2, i + scenario.count][2] for i in range(scenario.count)) == events["CC_STEP"][0][0]
    seed_flits = 132 if scenario.seed else 0
    assert events["PASS"][0][2] == seed_flits + 132 * len(plan.assignments)
    for i, (app, msg, is_decode, *_rest) in enumerate(rows):
        if i in plan.assignments:
            ready = events["INSTALL_READY"][0][0]
            assert binds[app, msg][1] == 1 and binds[app, msg][0] >= ready
        if is_decode:
            assert binds[app, msg][0] >= {a: g for a, _, g in events["GATE"]}[app]
    if plan != planner.KEEP:
        trigger, pending, occupied = events["CFG_TRIGGER"][0]
        applied, image = events["COMMIT"][0]
        drained = events["DRAIN"][0][0]
        assert image == plan.image and events["CFG_ACCEPT"][0][0] == applied
        assert applied >= max(trigger + 32, drained)
        assert events["INSTALL_READY"][0][0] == applied + 8
        if scenario.seed:
            assert pending > 0 and drained >= messages[scenario.seed[:2]][2]
    return Outcome(scenario, messages, binds, edges, flow, events, prefix.hexdigest(), directory)


def set_seed(scenario, packets, paths):
    if scenario.kind != "busy":
        return scenario
    # Seed the old configuration with an existing recorded prefill packet.
    # Move it out of the current dependency gate as a previous-wave carry-in.
    # Pick from a different endpoint than the largest pending source.
    workload = Counter(src for _, _, d, src, *_ in packets if not d)
    options = [(workload[src], len(paths[src, dst][0].switches), a, mid,
                paths[src, dst][0].image)
               for a, mid, d, src, dst, _ in packets if not d and (src, dst) in paths
               and dst != scenario.cc_dst and len(paths[src, dst][0].switches) <= 2]
    _, _, a, mid, image = min(options)
    prototype = Scenario(**{**scenario.__dict__, "seed": (a, mid, image), "decision": 16400})
    # The first actually transmitted old-packet flit supplies the decision anchor.
    seed_run = replay(prototype, packets, ROOT / "diagnostics" / scenario.name)
    first, plane = seed_run.events["SEED_TX"][0]
    assert plane == 1
    return Scenario(**{**prototype.__dict__, "decision": first + 1})


def write_csv(path, rows):
    with path.open("w", newline="") as out:
        writer = csv.DictWriter(out, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def for_export(result, arm, predictions, selected, baseline):
    s = result.scenario
    values = result.metrics
    txn_rows = []
    trx = result.scenario.count
    for i in range(trx):
        _, release, request = result.messages[2, i]
        _, response_rel, response = result.messages[2, i + trx]
        _, _, old_request = baseline.messages[2, i]
        _, _, old_response = baseline.messages[2, i + trx]
        txn_rows.append(dict(case=s.name, arm=arm, txn=i, release=release, request_done=request,
                             response_release=response_rel, response_done=response,
                             request_latency=request-release, response_latency=response-response_rel,
                             elapsed=response-release, request_delta=request-old_request,
                             response_done_delta=response-old_response))
    messages = [dict(case=s.name, arm=arm, app=a, id=mid, decode=d, release=rel, complete=end,
                     completion_delta=end-baseline.messages[a, mid][2],
                     source_binding=result.bindings[a, mid][0], plane=result.bindings[a, mid][1])
                for (a, mid), (d, rel, end) in sorted(result.messages.items())]
    freeze = result.events["SNAP"][0]
    summary = dict(case=s.name, kind=s.kind, arm=arm, waves="/".join(s.wave), cc_count=trx,
                   cc_route=f"{s.cc_src}->{s.cc_dst}", cc_start=s.cc_start, decision=s.decision,
                   applied=int(selected != planner.KEEP), paths=len(selected.paths),
                   cfg_hex=f"{selected.image:x}" if selected != planner.KEEP else "",
                   assignments=len(selected.assignments), CC_step=result.cc_step,
                   CC_elapsed=result.cc_step-s.cc_start, CC_gain=baseline.cc_step-result.cc_step,
                   A_decode=values["A_decode"], B_decode=values["B_decode"],
                   A_all=values["A_all"], B_all=values["B_all"],
                   A_decode_delta=values["A_decode"]-baseline.metrics["A_decode"],
                   B_decode_delta=values["B_decode"]-baseline.metrics["B_decode"],
                   A_all_delta=values["A_all"]-baseline.metrics["A_all"],
                   B_all_delta=values["B_all"]-baseline.metrics["B_all"],
                   cc_txn_worse=sum(r["response_done_delta"] > 0 for r in txn_rows),
                   old_pending=freeze[3], old_occupied=f"{freeze[4]:x}",
                   drain=result.events["DRAIN"][0][0] if selected != planner.KEEP else "",
                   commit=result.events["COMMIT"][0][0] if selected != planner.KEEP else "",
                   install_ready=result.events["INSTALL_READY"][0][0] if selected != planner.KEEP else "",
                   past_sha256=result.prefix_hash, evaluated=predictions)
    port = [dict(case=s.name, arm=arm, src=u, dst=v, app=a, id=mid, seq=seq, cycle=t)
            for u, v, a, mid, seq, t in result.edges if a == 2]
    return summary, txn_rows, messages, port


def experiment(spec, paths, workers):
    inputs = stimulus(spec.wave)
    scenario = set_seed(spec, inputs, paths)
    work = ROOT / "runs" / scenario.name
    prediction = replay(scenario, inputs, work / "prediction" / "s0")
    actual = replace(scenario, cc_start=scenario.cc_start + scenario.actual_cc_offset)
    actual_s0 = replay(actual, inputs, work / "validation" / "s0")
    assert actual_s0.prefix_hash == prediction.prefix_hash
    if not scenario.actual_cc_offset:
        assert actual_s0.messages == prediction.messages
    if scenario.seed:
        assert prediction.events["SNAP"][0][3] > 0
    eligible = [(i, *p) for i, p in enumerate(inputs)
                if prediction.bindings[p[:2]][0] >= scenario.decision and p[:2] != scenario.seed[:2]]
    flows = defaultdict(list)
    for i, a, mid, d, src, dst, rel in eligible:
        flows[a, src, dst].append(i)
    hot_scores = planner.overlap_scores(prediction, eligible, scenario.decision)
    std = planner.build_pool(flows, eligible, paths, scenario.cc_src, scenario.cc_dst, scenario.count)
    hot = (planner.build_pool(flows, eligible, paths, scenario.cc_src, scenario.cc_dst,
                              scenario.count, hot_scores) if hot_scores else [])
    std_pool, ext_pool = std[:planner.EVAL_LIMIT], planner.cap_pools(std, hot)
    union = list(dict.fromkeys(std_pool + ext_pool))

    def forecast(candidate):
        loc = work / "prediction" / f"{candidate.image:x}"
        result = replay(scenario, inputs, loc, candidate)
        assert result.prefix_hash == prediction.prefix_hash
        return result

    start = time.monotonic()
    with ThreadPoolExecutor(max_workers=workers) as executor:
        predicted = dict(zip(union, executor.map(forecast, union)))
    predicted_seconds = time.monotonic() - start
    selected = {}
    checks = []
    for arm in ARMS:
        candidates = ext_pool if arm in ("candidate_only", "both") else std_pool
        select = planner.new_choice if arm in ("submit_only", "both") else planner.old_choice
        choice, receipts = select(prediction, candidates, predicted)
        selected[arm] = (choice, len(candidates))
        for item in candidates:
            reason, gain, guard = receipts.get(item, ("ordered_after_selection", "", ""))
            forecasted = predicted[item]
            checks.append(dict(case=scenario.name, arm=arm, image=f"{item.image:x}",
                               routes=[(p.src, p.dst, p.switches) for p in item.paths],
                               packet_ids=[inputs[i][:2] for i in item.assignments], volume_flits=item.volume,
                               objective_improvement_with_margin=gain, guard_max_delta=guard,
                               reason=reason, selected=int(item == choice),
                               forecast_CC_gain=prediction.cc_step-forecasted.cc_step,
                               forecast_A_decode_delta=forecasted.metrics["A_decode"]-prediction.metrics["A_decode"],
                               forecast_B_decode_delta=forecasted.metrics["B_decode"]-prediction.metrics["B_decode"]))
    rows = [for_export(actual_s0, "s0", 0, planner.KEEP, actual_s0)]
    # Replay the chosen actions independently. These outputs never inform selection.
    for arm, (choice, count) in selected.items():
        result = replay(actual, inputs, work / "validation" / arm, choice)
        fore = predicted.get(choice, prediction)
        assert result.prefix_hash == actual_s0.prefix_hash
        if not scenario.actual_cc_offset:
            assert result.messages == fore.messages
        rows.append(for_export(result, arm, count, choice, actual_s0))
    manifest = dict(scenario=scenario.__dict__, packets=len(inputs), native_wave_metadata=(
                    "R0002 prefill and original offsets; held-out layer 0 expert IDs with 17-cycle offset spacing"),
                    synthetic_cc_release="exogenous planned arrivals, response on last request Bank completion",
                    decision_known_window=planner.WINDOW, candidates_per_arm=planner.EVAL_LIMIT,
                    per_path_choices=planner.PATH_LIMIT, candidate_wall_s=predicted_seconds,
                    scores={f"{a}:{src}:{dst}": count for (a, src, dst), count in hot_scores.items()},
                    forecasts=len(union))
    (work / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
    print(scenario.name, {row[0]["arm"]: (row[0]["applied"], row[0]["CC_gain"]) for row in rows},
          flush=True)
    return rows, checks, manifest


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--case", action="append")
    parser.add_argument("--workers", type=int, default=4)
    options = parser.parse_args()
    specs = [s for s in SCENARIOS if not options.case or s.name in options.case]
    assert specs
    paths = planner.wired_paths()
    path_data = [dict(src=p.src, dst=p.dst, switches=p.switches, image=f"{p.image:x}")
                 for key in sorted(paths) for p in paths[key]]
    (ROOT / "legal_paths.json").write_text(json.dumps(path_data, indent=2) + "\n")
    summary, transactions, messages, ports, checks, manifests = [], [], [], [], [], []
    for spec in specs:
        results, decisions, manifest = experiment(spec, paths, options.workers)
        manifests.append(manifest)
        checks.extend(decisions)
        for result, txns, msgs, observed_port in results:
            summary.append(result)
            transactions.extend(txns)
            messages.extend(msgs)
            ports.extend(observed_port)
        for file, output in (("paired_summary.csv", summary), ("transactions.csv", transactions),
                             ("messages.csv", messages), ("cc_port.csv", ports), ("decisions.csv", checks)):
            if output:
                write_csv(ROOT / file, output)
        (ROOT / "run_manifest.json").write_text(json.dumps(manifests, indent=2) + "\n")


if __name__ == "__main__":
    main()

