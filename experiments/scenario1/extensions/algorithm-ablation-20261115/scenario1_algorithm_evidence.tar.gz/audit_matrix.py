"""Audit the validation packet/transaction joins and report policy differences."""

from collections import Counter, defaultdict
import csv
import json
from pathlib import Path


ARMS = ("s0", "original", "candidate_only", "submit_only", "both")


def load(name):
    with open(name, newline="") as source:
        return list(csv.DictReader(source))


def write(name, rows):
    with open(name, "w", newline="") as dest:
        writer = csv.DictWriter(dest, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def main():
    summary = load("paired_summary.csv")
    transactions = load("transactions.csv")
    messages = load("messages.csv")
    decisions = load("decisions.csv")
    manifests = json.loads(Path("run_manifest.json").read_text())
    assert len(summary) == 70 and len(manifests) == 14
    by_case = defaultdict(dict)
    for row in summary:
        by_case[row["case"]][row["arm"]] = row
    by_transaction, by_messages, by_decision = defaultdict(list), defaultdict(list), defaultdict(list)
    for row in transactions:
        by_transaction[row["case"], row["arm"]].append(row)
    for row in messages:
        by_messages[row["case"], row["arm"]].append(row)
    for row in decisions:
        by_decision[row["case"], row["arm"]].append(row)
    rows = []
    for case, arms in by_case.items():
        assert set(arms) == set(ARMS)
        assert len({a["past_sha256"] for a in arms.values()}) == 1
        orig = arms["original"]
        for name, a in arms.items():
            msgs = by_messages[case, name]
            txns = by_transaction[case, name]
            checks = by_decision[case, name]
            a_step, cc_gain = int(a["CC_step"]), int(a["CC_gain"])
            assert len(txns) == int(a["cc_count"])
            assert a_step == max(int(t["response_done"]) for t in txns)
            assert all(t["request_done"] == t["response_release"] for t in txns)
            assert len({(m["app"], m["id"]) for m in msgs}) == len(msgs)
            assert len(checks) <= 8 and int(a["evaluated"]) == len(checks)
            assert sum(int(item["selected"]) for item in checks) == int(a["applied"])
            assert int(arms["s0"]["CC_step"]) - a_step == cc_gain
            applied = bool(int(a["applied"]))
            old_image = ""
            physically_changed = 0
            if not applied:
                assert all(int(m["completion_delta"]) == 0 for m in msgs)
            if a["kind"] == "busy":
                assert int(a["old_pending"]) and int(a["old_occupied"], 16)
                plan = Path("runs", case, "validation", name, "plan.stim")
                old_image, image = plan.read_text().splitlines()[0].split()
                if applied:
                    assert int(a["commit"]) >= int(a["drain"]) > int(a["decision"])
                    physically_changed = int(old_image != image)
            forecast_gain = ""
            if applied:
                forecast_gain = int(next(x for x in checks if int(x["selected"]))["forecast_CC_gain"])
                if a["kind"] != "forecast_offset":
                    assert forecast_gain == cc_gain
            rows.append(dict(
                case=case, kind=a["kind"], arm=name, switch=int(applied), CC_gain_vs_no_update=cc_gain,
                CC_gain_vs_original=int(orig["CC_step"])-a_step, predicted_CC_gain=forecast_gain,
                A_decode_cost_vs_original=int(a["A_decode"])-int(orig["A_decode"]),
                B_decode_cost_vs_original=int(a["B_decode"])-int(orig["B_decode"]),
                A_all_cost_vs_original=int(a["A_all"])-int(orig["A_all"]),
                B_all_cost_vs_original=int(a["B_all"])-int(orig["B_all"]),
                cc_txn_worst_vs_no_update=max(int(x["response_done_delta"]) for x in txns),
                old_pending=a["old_pending"], old_occupied=a["old_occupied"],
                old_cfg_hex=old_image, busy_config_changed=physically_changed,
                drain_cycles=int(a["drain"])-int(a["decision"]) if a["drain"] else "",
                trigger_to_ready=int(a["install_ready"])-int(a["decision"]) if a["install_ready"] else "",
            ))
    for name in ARMS:
        counts = Counter()
        for row in rows:
            if row["arm"] == name:
                gain = row["CC_gain_vs_no_update"]
                counts["switches"] += row["switch"]
                counts["cc_improved"] += gain > 0
                counts["cc_hurt"] += gain < 0
                counts["cc_equal"] += gain == 0
                counts["cc_over_original"] += row["CC_gain_vs_original"] > 0
        print(name, dict(counts))
    write("deltas_vs_original.csv", rows)
    print(f"Verified {len(summary)} arms, {len(transactions)} CC transactions, {len(messages)} packets.")


if __name__ == "__main__":
    main()

