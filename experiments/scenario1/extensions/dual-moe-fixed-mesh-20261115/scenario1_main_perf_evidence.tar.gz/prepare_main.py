"""Add a fixed-Mesh-only arm to the existing RTL performance harness."""

from pathlib import Path

path = Path("experiment_tb.sv")
source = path.read_text()
edits = (
    (" integer cc_src, cc_dst,", " integer cc_src, cc_dst, mesh_only,"),
    ("  send_aux=plane[j]>0 ||", "  send_aux=!mesh_only && (plane[j]>0 ||"),
    ("cfg_stage==2 && c>=last_ready)));\n endfunction",
     "cfg_stage==2 && c>=last_ready))));\n endfunction"),
    ('  if(!$value$plusargs("decision=%d",change_at)) change_at=16462;',
     '''  if(!$value$plusargs("decision=%d",change_at)) change_at=16462;
  if(!$value$plusargs("mesh_only=%d",mesh_only)) mesh_only=0;
  if(mesh_only) begin
   if(mode!=0) $fatal(1,"Mesh baseline cannot reconfigure");
   cfg_stage=1;
  end'''),
    ("  if(seed_flag != (|old_image)) $fatal;",
     """  if(mesh_only) begin
   if(old_image!=0 || next_image!=0) $fatal(1,"Mesh baseline received a CS image");
  end else if(seed_flag != (|old_image)) $fatal;"""),
    ("   if(cv && cr && cfg_stage==1 && cfg_tick<0) begin",
     """   if(mesh_only && (cv || av!=0 || arv!=0 || cs.occupied!=0 || cs.active!=0))
    $fatal(1,"CS activity in fixed-Mesh baseline");
   if(cv && cr && cfg_stage==1 && cfg_tick<0) begin"""),
    ("(seed_flag && plane[seed_index]!=1)", "(seed_flag && plane[seed_index]!=(mesh_only ? 0 : 1))"),
)
for before, after in edits:
    assert source.count(before) == 1, before
    source = source.replace(before, after)
path.write_text(source)

# Reuse the validated input generator, parser and protocol assertions for both arms.
path = Path("run_matrix.py")
source = path.read_text()
edits = (
    ("def replay(scenario, rows, directory, plan=planner.KEEP):",
     "def replay(scenario, rows, directory, plan=planner.KEEP, *, mesh_only=False):"),
    ("old_image = scenario.seed[2] if scenario.seed else 0",
     "old_image = scenario.seed[2] if scenario.seed and not mesh_only else 0"),
    ("ccdst=scenario.cc_dst, decision=scenario.decision, packets=len(rows))",
     "ccdst=scenario.cc_dst, decision=scenario.decision, packets=len(rows),\n                mesh_only=int(mesh_only))"),
    ("seed_flits = 132 if scenario.seed else 0",
     """seed_flits = 132 if scenario.seed and not mesh_only else 0
    if mesh_only:
        assert plan == planner.KEEP and not events["COMMIT"]
        assert events["SNAP"][0][3:] == (0, 0)
        if scenario.seed:
            assert events["SEED_TX"][0][1] == binds[scenario.seed[:2]][1] == 0"""),
)
for before, after in edits:
    assert source.count(before) == 1, before
    source = source.replace(before, after)
path.write_text(source)

