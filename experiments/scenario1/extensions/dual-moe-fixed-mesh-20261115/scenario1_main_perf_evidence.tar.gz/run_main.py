"""Replay the preselected algorithms against strictly fixed XY, including carry-in."""

import argparse
import ast
from collections import defaultdict
from concurrent.futures import ThreadPoolExecutor
import csv
from dataclasses import replace
import json
from pathlib import Path
import statistics

import planner
from run_matrix import ROOT, Scenario, for_export, replay, stimulus, write_csv


MEASURES = ("CC_elapsed", "A_decode", "B_decode", "A_all", "B_all")
ARM_LABELS = {"both": "B_full", "original": "original_ablation"}


def read_csv(path):
    with path.open(newline="") as stream:
        return list(csv.DictReader(stream))


def freeze_inputs(source):
    """Copy the prior selection and checks into a small self-contained input bundle."""
    dest = ROOT / "frozen"
    files = ["run_manifest.json", "decisions.csv", "paired_summary.csv", "messages.csv"]
    for file in files:
        path = dest / file
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes((source / file).read_bytes())
    manifest = json.loads((dest / "run_manifest.json").read_text())
    for row in manifest:
        for arm in ARM_LABELS:
            directory = Path("runs", row["scenario"]["name"], "validation", arm)
            (dest / directory).mkdir(parents=True, exist_ok=True)
            for file in ("unified.stim", "plan.stim", "args.json"):
                path = directory / file
                (dest / path).write_bytes((source / path).read_bytes())
    return dest


def preserved_plan(case, original_arm, packets, decisions, manifest, frozen):
    rows = [row for row in decisions.get((case, original_arm), []) if int(row["selected"])]
    assert len(rows) <= 1
    if rows:
        row = rows[0]
        paths = tuple(planner.Circuit(src, dst, switches)
                      for src, dst, switches in ast.literal_eval(row["routes"]))
        packet_ids = ast.literal_eval(row["packet_ids"])
        index = {packet[:2]: i for i, packet in enumerate(packets)}
        assignment = tuple(sorted(index[packet_id] for packet_id in packet_ids))
        plan = planner.Candidate(paths, assignment)
        assert f"{plan.image:x}" == row["image"] and plan.volume == int(row["volume_flits"])
    else:
        plan = planner.KEEP
    old_image = manifest["scenario"]["seed"][2] if manifest["scenario"]["seed"] else 0
    old_dir = frozen / "runs" / case / "validation" / original_arm
    lines = (old_dir / "plan.stim").read_text().splitlines()
    assert tuple(int(item, 16) for item in lines[0].split()) == (old_image, plan.image)
    assert tuple(int(item) for item in lines[1:]) == plan.assignments
    assert (old_dir / "unified.stim").read_text().splitlines() == [
        " ".join(map(str, packet)) for packet in packets
    ]
    return plan, old_dir


def experiment(manifest, decisions, prior_summary, prior_packets, frozen):
    spec = manifest["scenario"]
    scenario = Scenario(**{**spec, "wave": tuple(spec["wave"]), "seed": tuple(spec["seed"])})
    actual = replace(scenario, cc_start=scenario.cc_start + scenario.actual_cc_offset)
    packets = stimulus(scenario.wave)
    assert len(packets) == manifest["packets"]
    runs = ROOT / "main_runs" / scenario.name
    base = replay(actual, packets, runs / "B", mesh_only=True)
    assert all(plane == 0 for tick, plane in base.bindings.values())

    def neutral(values):
        return {key: value for key, value in values.items() if key not in ("mesh_only", "mode")}

    baseline_args = neutral(json.loads((base.path / "args.json").read_text()))
    results = [("B", base, planner.KEEP, 0)]
    for old_arm, label in ARM_LABELS.items():
        plan, old_dir = preserved_plan(scenario.name, old_arm, packets, decisions, manifest, frozen)
        trial = replay(actual, packets, runs / label, plan)
        old_args = json.loads((old_dir / "args.json").read_text())
        new_args = json.loads((trial.path / "args.json").read_text())
        assert neutral(new_args) == neutral(old_args) == baseline_args
        assert new_args["mode"] == old_args["mode"]
        assert (trial.path / "unified.stim").read_bytes() == (base.path / "unified.stim").read_bytes()
        assert trial.messages == prior_packets[scenario.name, old_arm]
        assert trial.cc_step == int(prior_summary[scenario.name, old_arm]["CC_step"])
        assert trial.prefix_hash == prior_summary[scenario.name, old_arm]["past_sha256"]
        for request in range(scenario.count):
            assert base.messages[2, request][1] == trial.messages[2, request][1]
        if scenario.seed:
            assert base.messages[scenario.seed[:2]][1] == trial.messages[scenario.seed[:2]][1] == 16400
            assert base.events["SEED_TX"][0][1] == 0 and trial.events["SEED_TX"][0][1] == 1
        else:
            assert base.prefix_hash == trial.prefix_hash
        results.append((label, trial, plan, int(prior_summary[scenario.name, old_arm]["evaluated"])))

    summary, transactions, messages, ports = [], [], [], []
    for label, result, plan, evaluated in results:
        row, txns, msgs, port = for_export(result, label, evaluated, plan, base)
        row["seed_completion"] = result.messages[scenario.seed[:2]][2] if scenario.seed else ""
        row["seed_plane"] = result.events["SEED_TX"][0][1] if scenario.seed else ""
        row["seed_flits_on_aux"] = 132 if scenario.seed and label != "B" else 0
        summary.append(row)
        transactions.extend(txns)
        messages.extend(msgs)
        ports.extend(port)
    print(scenario.name, [(row["arm"], row["CC_elapsed"], row["A_all"], row["B_all"])
                           for row in summary], flush=True)
    return summary, transactions, messages, ports


def paired_table(summary, arm):
    base = {row["case"]: row for row in summary if row["arm"] == "B"}
    result = []
    for row in summary:
        if row["arm"] != arm:
            continue
        ref = base[row["case"]]
        comparison = {k: row[k] for k in ("case", "kind", "waves", "cc_count", "cc_start",
                                          "decision", "applied", "cfg_hex", "old_occupied",
                                          "drain", "commit", "install_ready")}
        comparison["B_seed_completion"] = ref["seed_completion"]
        comparison["design_seed_completion"] = row["seed_completion"]
        for m in MEASURES:
            comparison[f"B_{m}"] = ref[m]
            comparison[f"design_{m}"] = row[m]
            comparison[f"{m}_cycles_saved"] = ref[m] - row[m]
            comparison[f"{m}_reduction_pct"] = round(100 * (ref[m] - row[m]) / ref[m], 6)
        comparison["cc_txn_worse"] = row["cc_txn_worse"]
        result.append(comparison)
    return result


def aggregate(table):
    groups = {"all_14": table}
    for kind in ("development", "holdout", "forecast_offset", "staggered", "busy"):
        groups[kind] = [row for row in table if row["kind"] == kind]
    groups["all_holdout"] = groups["holdout"] + groups["forecast_offset"]
    rows = []
    for group, cases in groups.items():
        for metric in MEASURES:
            deltas = [row[f"{metric}_cycles_saved"] for row in cases]
            pcts = [row[f"{metric}_reduction_pct"] for row in cases]
            base = sum(row[f"B_{metric}"] for row in cases)
            rows.append(dict(group=group, metric=metric, cases=len(cases),
                             improved=sum(delta > 0 for delta in deltas),
                             unchanged=sum(delta == 0 for delta in deltas),
                             regressed=sum(delta < 0 for delta in deltas),
                             mean_reduction_pct=round(statistics.mean(pcts), 6),
                             median_reduction_pct=round(statistics.median(pcts), 6),
                             min_reduction_pct=min(pcts), max_reduction_pct=max(pcts),
                             pooled_reduction_pct=round(100 * sum(deltas) / base, 6)))
    return rows


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--freeze-from", type=Path)
    parser.add_argument("--workers", type=int, default=4)
    options = parser.parse_args()
    frozen = freeze_inputs(options.freeze_from.resolve()) if options.freeze_from else ROOT / "frozen"
    manifests = json.loads((frozen / "run_manifest.json").read_text())
    decisions, messages = defaultdict(list), defaultdict(dict)
    for row in read_csv(frozen / "decisions.csv"):
        decisions[row["case"], row["arm"]].append(row)
    for row in read_csv(frozen / "messages.csv"):
        if row["arm"] in ARM_LABELS:
            messages[row["case"], row["arm"]][int(row["app"]), int(row["id"])] = (
                int(row["decode"]), int(row["release"]), int(row["complete"]))
    prior_summary = {(row["case"], row["arm"]): row
                     for row in read_csv(frozen / "paired_summary.csv")}

    def task(item):
        return experiment(item, decisions, prior_summary, messages, frozen)

    outputs = [[], [], [], []]
    with ThreadPoolExecutor(max_workers=options.workers) as runner:
        for result in runner.map(task, manifests):
            for output, rows in zip(outputs, result):
                output.extend(rows)
    for name, rows in zip(("all_arms.csv", "transactions.csv", "messages.csv", "cc_port.csv"), outputs):
        write_csv(ROOT / name, rows)
    main_results = paired_table(outputs[0], "B_full")
    original_results = paired_table(outputs[0], "original_ablation")
    assert len(outputs[0]) == 42 and len(main_results) == len(original_results) == 14
    assert sum(row["kind"] == "busy" for row in main_results) == 3
    enriched = []
    for original, full in zip(original_results, main_results):
        assert original["case"] == full["case"]
        extra = {f"{m}_full_reduction_vs_original_pct": round(
            100 * (original[f"design_{m}"] - full[f"design_{m}"]) / original[f"design_{m}"], 6)
                 for m in MEASURES}
        enriched.append({**original, **extra})
    write_csv(ROOT / "main_paired.csv", main_results)
    write_csv(ROOT / "main_aggregate.csv", aggregate(main_results))
    write_csv(ROOT / "original_ablation.csv", enriched)
    print("PASS", len(main_results), "pairs,", len(outputs[0]), "arms,",
          len(outputs[1]), "CC transactions,", len(outputs[2]), "messages", flush=True)


if __name__ == "__main__":
    main()

