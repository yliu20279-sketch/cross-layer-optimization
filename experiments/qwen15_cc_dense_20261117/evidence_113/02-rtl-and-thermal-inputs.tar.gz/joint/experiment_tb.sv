module unified_tb;
 parameter WEIGHTED=0;
 reg clk=0; always #5 clk=~clk;
 reg reset=1, cv=0;
 reg [77:0] cfg=0;
 wire cr,applied,rejected;
 reg [1103:0] md=0;
 reg [1039:0] ad=0;
 wire [1039:0] mo,ao;
 reg [15:0] mv=0,av=0,mrr=0,arr=0;
 wire [15:0] mr,ar,mrv,arv;
 mesh16 #(.W(65),.WEIGHTED(WEIGHTED)) mesh(clk,reset,md,mv,mrr,mr,mrv,mo);
 aux13 #(.W(65)) cs(clk,reset,cv,cfg,cr,applied,rejected,ad,av,arr,ar,arv,ao);
 integer app[2400], id[2400], dec[2400], src[2400], dst[2400], rel[2400];
 integer sent[2400], got[2400], free_at[16][8], pick[16], read_bank[16], read_at[16], read_msg[16];
 integer priority_on, active_msg[16], owe_prefill[16], decode_pick[16], prefill_pick[16];
 integer depth, issued[2400], head[16], tail[16], occupancy[16], fifo_msg[16][8], fifo_at[16][8], peak=0;
 integer mode, bank_cycles, ctrl, install, f,i,n,b,c,q,g=0,total=0,commit=-1,cs_count=0;
 integer a_grants=0,b_grants=0;
 integer active, cc_count, cc_start, cc_policy, indep, delay_a, b_offset, config_start=-1, cfg_tick=-1;
 integer nframes, len[2400], pre_left[2], pre_done[2], gates[2], phase_origin[2];
 integer cc_period, rsp_left, cc_step=-1, expected_cs=0, committed_cfg=0;
 integer rtl_done[2400];
 integer phase[2400], plane[2400], planned[2400];
 integer app_count, change_at, seed_app, seed_id, seed_index=-1, seed_cycle, seed_flag=0;
 integer cc_src, cc_dst, mesh_only, cfg_stage=0, aux_pending=0, aux_last_bank=0, last_ready=-1;
 integer cmd_file, cmd_result, selected, total_prefill=0;
 reg [77:0] old_image, next_image;
 reg other_grant;
 function automatic bit ends_on_cc_request(input integer j);
  ends_on_cc_request=app[j]==2 && id[j]<cc_count;
 endfunction
 function automatic bit send_aux(input integer j);
  send_aux=!mesh_only && (plane[j]>0 || (plane[j]<0 && ((j==seed_index && cfg_stage==1) ||
           (planned[j] && mode==2 && cfg_stage==2 && c>=last_ready))));
 endfunction
 function automatic bit xy_edge(input integer u, input integer v, input integer start, input integer stop);
  integer x, y, tx, ty, here, next_hop, k;
  begin
   x=start%4; y=start/4; tx=stop%4; ty=stop/4; xy_edge=0;
   for(k=0;k<6;k++) begin
    here=4*y+x;
    if(x<tx) x++; else if(x>tx) x--; else if(y<ty) y++; else if(y>ty) y--;
    next_hop=4*y+x;
    if(here==u && next_hop==v && here!=next_hop) xy_edge=1;
   end
  end
 endfunction
 function automatic bit ready_at(input integer j);
  if(app[j]==2) ready_at=c>=rel[j];
  else if(indep && dec[j]) ready_at=gates[app[j]]>=0 && c>=rel[j];
  else ready_at=c>=rel[j];
 endfunction

 reg [64:0] payload;
 function automatic bit diverted(input integer j);
  diverted=send_aux(j);
 endfunction
 function automatic integer bank(input integer j,input integer seq_id);
  bank=(id[j]+seq_id)%8;
 endfunction
 function automatic bit watch(input integer j); watch=app[j]==2 || src[j]==4 || src[j]==1; endfunction
 initial begin
  if(!$value$plusargs("mode=%d",mode) || !$value$plusargs("bank=%d",bank_cycles) ||
     !$value$plusargs("ctrl=%d",ctrl) || !$value$plusargs("install=%d",install)) $fatal;
  if(!$value$plusargs("priority=%d",priority_on)) priority_on=0;
  if(!$value$plusargs("depth=%d",depth) || depth<1 || depth>8) $fatal;
  if(bank_cycles<1 || ctrl<1 || install<1 || (mode==1 && !WEIGHTED)) $fatal;
  if(!$value$plusargs("active=%d",active)) active=1;
  if(!$value$plusargs("cc=%d",cc_count)) cc_count=0;
  if(!$value$plusargs("ccstart=%d",cc_start)) cc_start=17000;
  if(!$value$plusargs("ccperiod=%d",cc_period)) cc_period=1;
  if(!$value$plusargs("ccpolicy=%d",cc_policy)) cc_policy=0;
  if(!$value$plusargs("indep=%d",indep)) indep=1;
  if(!$value$plusargs("delay_a=%d",delay_a)) delay_a=0;
  if(!$value$plusargs("b_offset=%d",b_offset)) b_offset=0;
  if(cc_count<0 || cc_count>1000 || cc_period<1 || mode<0 || mode>2) $fatal;
  for(i=0;i<2;i++) begin
   pre_left[i]=0; pre_done[i]=-1; gates[i]=-1; phase_origin[i]=999999;
  end
  if(!$value$plusargs("decision=%d",change_at)) change_at=16462;
  if(!$value$plusargs("mesh_only=%d",mesh_only)) mesh_only=0;
  if(mesh_only) begin
   if(mode!=0) $fatal(1,"Mesh baseline cannot reconfigure");
   cfg_stage=1;
  end
  if(!$value$plusargs("seedapp=%d",seed_app)) seed_app=-1;
  if(!$value$plusargs("seedid=%d",seed_id)) seed_id=-1;
  if(!$value$plusargs("seedcycle=%d",seed_cycle)) seed_cycle=16400;
  if(!$value$plusargs("ccsrc=%d",cc_src)) cc_src=0;
  if(!$value$plusargs("ccdst=%d",cc_dst)) cc_dst=9;
  if(!$value$plusargs("packets=%d",app_count)) app_count=260;
  cmd_file=$fopen("plan.stim","r");
  if(!cmd_file || $fscanf(cmd_file,"%h %h",old_image,next_image)!=2) $fatal(1,"missing config images");
  nframes=(active ? app_count : 0)+2*cc_count;
  if(nframes>2400 || cc_src==cc_dst) $fatal;
  rsp_left=cc_count;
  f=$fopen("unified.stim","r");
  for(i=0;i<app_count && active;i++) begin
   if($fscanf(f,"%d %d %d %d %d %d",app[i],id[i],dec[i],src[i],dst[i],rel[i])!=6) $fatal;
   if(app[i]==1) rel[i]+=b_offset;
   if(dec[i] && rel[i]<phase_origin[app[i]]) phase_origin[app[i]]=rel[i];
   if(app[i]==seed_app && id[i]==seed_id) begin
    if(dec[i]) $fatal;
    seed_index=i;
    seed_flag=1;
    rel[i]=seed_cycle;
   end else if(!dec[i]) pre_left[app[i]]++;
   sent[i]=0; issued[i]=0; got[i]=0; len[i]=132; rtl_done[i]=-1;
   plane[i]=-1; planned[i]=0;
   if(!dec[i]) total_prefill++;
   end
  if(mesh_only) begin
   if(old_image!=0 || next_image!=0) $fatal(1,"Mesh baseline received a CS image");
  end else if(seed_flag != (|old_image)) $fatal;
  begin
  end
  $fclose(f);
  for(i=(active ? app_count : 0);i<nframes;i++) begin
   app[i]=2; id[i]=i-(active ? app_count : 0); dec[i]=0;
   src[i]=id[i]<cc_count ? cc_src : cc_dst; dst[i]=id[i]<cc_count ? cc_dst : cc_src;
   rel[i]=id[i]<cc_count ? cc_start+id[i]*cc_period : 1000000;
   len[i]=id[i]<cc_count ? 1 : 3; sent[i]=0; issued[i]=0; got[i]=0; plane[i]=-1; planned[i]=0; rtl_done[i]=-1;
  end
  while(!$feof(cmd_file)) begin
   cmd_result=$fscanf(cmd_file,"%d",selected);
   if(cmd_result==1) begin
    if(selected<0 || selected>=nframes || selected==seed_index) $fatal;
    planned[selected]=1;
   end
  end
  $fclose(cmd_file);
  for(n=0;n<16;n++) begin
   head[n]=0; tail[n]=0; occupancy[n]=0; active_msg[n]=-1; owe_prefill[n]=0;
   for(b=0;b<8;b++) free_at[n][b]=0;
  end
  repeat(2) @(negedge clk); reset=0;
  for(c=0;c<150000 && g<nframes;c++) begin
   #1;
   if(c<=8) $display("RXTRACE,%0d,%b,%h,%h,%h",c,mrv[0],mesh.out_flit[0][4*69+:69],mo[0+:65],mesh.routers[0].r.full);
   for(int a=0;a<2;a++) begin
    if(active && indep && gates[a]<0 && pre_done[a]>=0 &&
       c>=pre_done[a]+(a==0 ? delay_a : 0)) begin
     gates[a]=c;
     $display("GATE,%0d,%0d,%0d",a,pre_done[a],c);
     for(int j=0;j<app_count;j++) if(app[j]==a && dec[j]) rel[j]=c+rel[j]-phase_origin[a];
    end
   end
   if(c==change_at) begin
    for(int j=0;j<nframes;j++)
     if(planned[j] && (plane[j]>=0 || issued[j]!=0))
      $fatal(1,"Selected frame %0d bound before decision",j);
    $display("SNAP,%0d,%0d,%0d,%0d,%0h",c,gates[0],gates[1],aux_pending,cs.occupied);
    if(mode==2) begin
     config_start=c;
     $display("CFG_TRIGGER,%0d,%0d,%0h",c,aux_pending,cs.occupied);
    end
   end
   cv=0;
   if(cfg_stage==0) begin
    cfg=old_image; cv=1;
   end else if(cfg_stage==1 && config_start>=0) begin
    if(aux_pending==0 && c>=aux_last_bank && committed_cfg==0) begin
     $display("DRAIN,%0d",c);
     committed_cfg=1;
    end
    if(committed_cfg && c>=config_start+ctrl) begin
     cfg=next_image; cv=1;
    end
   end
   if(mesh_only && (cv || av!=0 || arv!=0 || cs.occupied!=0 || cs.active!=0))
    $fatal(1,"CS activity in fixed-Mesh baseline");
   if(cv && cr && cfg_stage==1 && cfg_tick<0) begin
    cfg_tick=c;
    $display("CFG_ACCEPT,%0d",c);
   end
   if(cfg_stage==2 && c==last_ready) $display("INSTALL_READY,%0d",c);
   mv=0; av=0; mrr=0; arr=0;
   for(n=0;n<16;n++) begin
    pick[n]=-1; decode_pick[n]=-1; prefill_pick[n]=-1;
    read_bank[n]=-1;
   end
   // Destination writes have priority. Each NI accepts one flit per cycle.
   for(n=0;n<16;n++) begin
    if(mrv[n] || arv[n]) begin
     payload=mrv[n] ? mo[n*65+:65] : ao[n*65+:65];
     q=payload[63:32];
     if(q<0 || q>=nframes || dst[q]!=n || payload[31:0]!=got[q] ||
        diverted(q)!=!mrv[n]) $fatal(1,"bad RX at %0d node %0d q %0d dest %0d seq %0d got %0d mesh %b aux %b",c,n,q,dst[q],payload[31:0],got[q],mrv[n],arv[n]);
     b=bank(q,got[q]);
     if(app[q]==2) $display("FLOW,RX,%0d,%0d,%0d,%0d,%0d",app[q],id[q],got[q],c,c>=free_at[n][b]);
     if(c>=free_at[n][b]) begin
      if(mrv[n]) mrr[n]=1; else begin arr[n]=1; cs_count++; end
      free_at[n][b]=c+bank_cycles;
      got[q]++; total++;
      if(got[q]==len[q]) begin
       g++; rtl_done[q]=c+bank_cycles;
       $display("DONE,%0d,%0d,%0d,%0d,%0d",app[q],id[q],dec[q],rel[q],rtl_done[q]);
       if(plane[q]) begin
        aux_pending--;
        if(rtl_done[q]>aux_last_bank) aux_last_bank=rtl_done[q];
       end
       if(app[q]<2 && !dec[q] && q!=seed_index) begin
        pre_left[app[q]]--;
        if(pre_left[app[q]]==0) pre_done[app[q]]=rtl_done[q];
       end
       if(app[q]==2 && id[q]<cc_count) begin
        rel[q+cc_count]=rtl_done[q];
        $display("RESPONSE_RELEASE,%0d,%0d",id[q],rel[q+cc_count]);
       end
       if(app[q]==2 && id[q]>=cc_count) begin
        rsp_left--;
        if(rsp_left==0) begin cc_step=rtl_done[q]; $display("CC_STEP,%0d",cc_step); end
       end
      end
     end
    end
   end
   // One pending source read per NI, shared by both planes.
   for(i=0;i<nframes;i++) begin
    n=src[i];
    if(ready_at(i) && sent[i]<len[i] &&
       (!(planned[i] && mode==2 && c>=change_at && plane[i]<0)
        || (cfg_stage==2 && c>=last_ready))) begin
     if(pick[n]<0) pick[n]=i;
     if(app[i]==2 && cc_policy) pick[n]=i;
     if(app[i]<2 && dec[i] && decode_pick[n]<0) decode_pick[n]=i;
     if(app[i]<2 && !dec[i] && prefill_pick[n]<0) prefill_pick[n]=i;
    end
   end
   for(n=0;n<16;n++) begin
    if(priority_on && !(pick[n]>=0 && app[pick[n]]==2)) begin
     if(active_msg[n]>=0) pick[n]=active_msg[n];
     else if(owe_prefill[n] && prefill_pick[n]>=0) pick[n]=prefill_pick[n];
     else if(decode_pick[n]>=0) pick[n]=decode_pick[n];
    end
    if(occupancy[n]<depth && pick[n]>=0 && issued[pick[n]]<len[pick[n]]) begin
     q=pick[n]; b=bank(q,issued[q]);
     if(app[q]==2) $display("FLOW,READ,%0d,%0d,%0d,%0d,%0d",app[q],id[q],issued[q],c,c>=free_at[n][b]);
     if(c>=free_at[n][b]) begin
      free_at[n][b]=c+bank_cycles;
      if(priority_on && active_msg[n]<0 && app[q]<2) begin
       active_msg[n]=q;
       owe_prefill[n]=dec[q] && prefill_pick[n]>=0;
       $display("SCHED,%0d,%0d,%0d,%0d,%0d,%0d",n,app[q],id[q],dec[q],c,owe_prefill[n]);
      end
      if(plane[q]<0) begin
       plane[q]=send_aux(q);
       if(plane[q]) aux_pending++;
       $display("BIND,%0d,%0d,%0d,%0d",app[q],id[q],c,plane[q]);
      end
      fifo_msg[n][tail[n]]=q;
      fifo_at[n][tail[n]]=c+bank_cycles;
      tail[n]=(tail[n]+1)%8; occupancy[n]++; issued[q]++;
      if(occupancy[n]>peak) peak=occupancy[n];
     end
    end
    q=fifo_msg[n][head[n]];
    if(occupancy[n]>0 && c>=fifo_at[n][head[n]]) begin
     payload=0; payload[64]=app[q][0]; payload[63:32]=q; payload[31:0]=sent[q];
     if(diverted(q)) begin av[n]=1; ad[n*65+:65]=payload; end
     else begin mv[n]=1; md[n*69+:69]={dst[q][3:0],payload}; end
    end
   end
   #1;
   for(n=0;n<16;n++) if((mv[n] && mr[n]) || (av[n] && ar[n])) begin
    if(c<=8) $display("TXTRACE,%0d,%0d,%h",c,n,md[n*69+:69]);
    q=fifo_msg[n][head[n]];
    if(app[q]==2) $display("FLOW,TX,%0d,%0d,%0d,%0d,1",app[q],id[q],sent[q],c);
    if(q==seed_index && sent[q]==0) $display("SEED_TX,%0d,%0d",c,plane[q]);
    sent[q]++; head[n]=(head[n]+1)%8; occupancy[n]--;
    if(priority_on && sent[q]==len[q] && app[q]<2) active_msg[n]=-1;
    if(app[q]<2 && dec[q]) begin
     if(indep && (gates[app[q]]<0 || c<gates[app[q]])) $fatal(1,"early decode");
     if(sent[q]==1) $display("DECODE_TX,%0d,%0d,%0d",app[q],id[q],c);
    end
   end
   for(int u=0;u<16;u++) for(int op=0;op<4;op++) begin
    int v;
    v=op==0 ? u+1 : op==1 ? u-1 : op==2 ? u+4 : u-4;
    if(mesh.ov[u][op]) begin
     payload=mesh.out_flit[u][op*69+:65]; q=payload[63:32];
     if(mesh.rd[u][op])
      $display("EDGE,%0d,%0d,%0d,%0d,%0d,%0d",u,v,app[q],id[q],payload[31:0],c);
    end
   end
   if(mesh.ov[5][2] && mesh.rd[5][2]) begin
    if(mesh.out_flit[5][2*69+64]) b_grants++; else a_grants++;
   end
   @(negedge clk);
   if(rejected) $fatal;
   if(applied) begin
    if(cfg_stage==0) begin
     $display("INITIAL,%0d,%0h",c,old_image);
     cfg_stage=1;
    end else begin
     cfg_stage=2; commit=c; last_ready=c+install;
     $display("COMMIT,%0d,%0h",c,next_image);
    end
   end
  end
  if(g!=nframes || total!=(active ? app_count*132 : 0)+4*cc_count || aux_pending!=0 ||
     rsp_left!=0 || (mode==2 && commit<0) || (seed_flag && plane[seed_index]!=(mesh_only ? 0 : 1)))
      $fatal(1,"counts %0d %0d",total,cs_count);
  $display("DEPTH,%0d,%0d",depth,peak);
  $display("PASS,%0d,%0d,%0d,%0d,%0d",mode,total,cs_count,a_grants,b_grants);
  $finish;
 end

 // Observe each CC flit that is already at the head of a router input.
 // The sampled grant and readiness are the same combinational signals used
 // by the router on this edge. This probe does not influence arbitration.
 for(genvar r=0;r<16;r++) begin: cc_probe
  always @(posedge clk) if(!reset && cc_count>0) begin
   for(int ip=0;ip<5;ip++) begin
    int d, q, op, v, selected_q, ready, grant_here, other_app;
    q=mesh.routers[r].r.queued[ip][63:32];
    if(mesh.routers[r].r.full[ip] && q>=0 && q<nframes) begin
     d=int'(mesh.routers[r].r.queued[ip][68:65]);
     op=d%4>r%4 ? 0 : d%4<r%4 ? 1 : d/4>r/4 ? 2 : d/4<r/4 ? 3 : 4;
     if(op<4) begin
      v=op==0 ? r+1 : op==1 ? r-1 : op==2 ? r+4 : r-4;
      ready=mesh.rd[r][op];
      grant_here=mesh.routers[r].r.grant[op][ip];
      selected_q=mesh.out_flit[r][op*69+32+:32];
      other_app=ready && mesh.ov[r][op] && !grant_here ? app[selected_q] : -1;
      if(app[q]==2) $display("CC_HEAD,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d",
               id[q],mesh.routers[r].r.queued[ip][31:0],r,v,c,ready,grant_here,other_app);
      if(app[q]==0 && other_app==2 && ready && !grant_here)
       $display("MOE_LOSS,%0d,%0d,%0d,%0d,%0d",id[q],mesh.routers[r].r.queued[ip][31:0],r,v,c);
     end
    end
   end
  end
 end
endmodule








