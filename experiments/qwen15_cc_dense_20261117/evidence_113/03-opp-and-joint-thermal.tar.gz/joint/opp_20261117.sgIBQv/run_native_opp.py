"""Run the frozen real-weight layer through the live OPP-aware backend."""

import csv
import hashlib
import json
from pathlib import Path
import struct
import sys
import traceback


def load(path):
    return json.loads(path.read_text())


def sha(data):
    return hashlib.sha256(data).hexdigest()


def save(path, obj):
    path.write_text(json.dumps(obj, indent=2) + '\n')


def main(root, binary, frozen_services, out, opp):
    from core.artifacts import TargetArtifactStore
    from core.coupled_backend import LiveBackend, CoupledPayload, CoupledTransport, MAGIC
    from core.coupled_layer import CoupledLayer
    from core.coupled_decoder import DecoderSlice
    from models.qwen15 import SPEC

    out.mkdir()
    freeze = root / 'runs/qwen15_pp56rmsfixed'
    hidden = (freeze / 'prefill_L5_input.bin').read_bytes()
    expected = load(freeze / 'RESULT.json')['phases'][0]
    frozen = load(frozen_services)
    scheduled = [e for s in frozen['segments'] for e in s['events'] if e['kind'] == 'native_matrix_rpc']
    assert len(scheduled) == 25
    raw = (freeze / 'NUMERIC_CALLS.json').read_bytes()
    assert sha(raw) == frozen['source_hashes']['NUMERIC_CALLS.json']
    expected_calls = {row['FP32_result_handle']:row for row in json.loads(raw)}
    cfg = load(root / 'upstream/qwen15_config.json')
    codec = load(root / 'evidence/REMOTE_BUILD_LIVE_02.json')
    placement = load(freeze / 'PROTOCOL.json')['placement']
    store = TargetArtifactStore(list(load(root / 'contracts/qwen15_tensor_inventory.json')['objects'].values()), 'F16')
    save(out / 'INPUTS.json', dict(input_sha256=sha(hidden), frozen_sha256=sha(frozen_services.read_bytes()),
                                  binary_sha256=sha(binary.read_bytes()), opp_quarters=opp))
    backend = LiveBackend(str(binary), sha(binary.read_bytes()), out / 'backend', str(root/'ramulator32.yaml'), timeout=3600)
    try:
        native = CoupledPayload(backend, codec['payload_library'], codec['payload_sha256'])
        transport = CoupledTransport(native)
        layer = CoupledLayer(SPEC, cfg, store, native, transport, placement, 'F16')
        layer.request_owner = 1
        original_rpc = backend.rpc
        cursor = 0
        decisions = []

        def rpc(opcode, *args, **kwargs):
            nonlocal cursor
            label = native.label
            if opcode != 5 or not label.startswith('model.layers.5.mlp.') or label.endswith('.mlp.gate'):
                return original_rpc(opcode, *args, **kwargs)
            assert cursor < len(scheduled), label
            item = scheduled[cursor]
            _, _, _, m, n, k, fp16 = args
            assert [m,k,n] == item['mkn'] and fp16 and native.partition==item['partition'] and label==item['label']
            ready = backend.clock
            # Mode 0 is a separate actuator probe; the first real target
            # matrix is deliberately deferred and run at the 3/4 setting.
            ratio = opp or (3 if cursor == 0 else 4)
            release = ready + (1000000 if opp == 0 and cursor == 0 else 0)
            backend.process.stdin.write(struct.pack('<8Q',14,ratio,release,0,0,0,0,0))
            backend.process.stdin.flush()
            ack = struct.unpack('<8Q',backend._read(64))
            assert ack[0]==MAGIC
            if ack[1]:
                raise RuntimeError(backend._read(ack[2]).decode())
            assert ack[7] == ready
            decision = dict(index=cursor, label=label, requested_release=release, ready=ready, opp_quarters=ratio)
            print(json.dumps(decision), flush=True)
            cursor += 1
            reply = original_rpc(opcode, *args, **kwargs)
            decision['complete'] = backend.clock
            decisions.append(decision)
            save(out / 'PROGRESS.json', decisions)
            return reply

        backend.rpc = rpc
        output = DecoderSlice(layer).forward(hidden,[0],[17],5,6)
        assert sha(output) == expected['output_sha256']
        assert cursor == len(decisions) == len(scheduled)
        assert layer.phases[0]['routes'][0]['selected'] == expected['routes'][0]['selected']
        actual_calls = [e for e in native.calls if e['label'].startswith('model.layers.5.mlp.') and not e['label'].endswith('.mlp.gate')]
        assert len(actual_calls) == len(scheduled)
        for observed, item in zip(actual_calls, scheduled):
            original = expected_calls[item['output_handle']]
            assert all(observed[k] == original[k] for k in ('label','MKN','source_sha256','output_sha256'))
        layer.close()
        native.close_weights()
        summary = backend.close()
        with (out/'backend/OPP_MATRIX.csv').open() as stream:
            timing = [{k:int(v) for k,v in row.items()} for row in csv.DictReader(stream)]
        assert len(timing) == len(decisions)
        lowering = {j['job']:j for j in map(json.loads, (out/'backend/LOWERING.jsonl').read_text().splitlines())}
        for row, decision in zip(timing, decisions):
            assert row['opp_quarters']==decision['opp_quarters'] and row['requested_release']==decision['requested_release']
            assert row['actual_start']==row['requested_release'] and row['rpc_ready']==decision['ready']
            assert row['complete'] == decision['complete'] >= row['actual_start']
            lower=lowering[row['job']]
            assert lower['begin'] == row['actual_start'] and lower['complete'] == row['complete']
            row['compute_cycles'],row['sram_bank_cycles']=lower['compute_cycles'],lower['bank_cycles']
        result=dict(status='PASS_NATIVE_OPP_ACTUATOR_PROBE' if not opp else 'PASS_NATIVE_OPP_CALIBRATION',
                    opp_quarters=opp, matrices=len(timing), output_sha256=sha(output),
                    target_complete=layer.phases[0]['complete'], backend_summary=summary, timing=timing)
        save(out/'RESULT.json',result)
        print(json.dumps({k:v for k,v in result.items() if k!='timing'}),flush=True)
    except BaseException:
        (out/'ERROR.txt').write_text(traceback.format_exc())
        if not backend.closed:
            backend.abort()
        raise


if __name__=='__main__':
    _, root, binary, frozen, out, setting = sys.argv
    root, binary, frozen, out = (Path(p).resolve() for p in (root,binary,frozen,out))
    sys.path.insert(0,str(root))
    main(root,binary,frozen,out,int(setting))
